import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Student,
  Teacher,
  Course,
  AttendanceRecord,
  Exam,
  StudentMark,
  FeeRecord,
  TimetableSlot,
  Notification,
  UserRole,
  ActiveTab
} from '../types';
import {
  INITIAL_STUDENTS,
  INITIAL_TEACHERS,
  INITIAL_COURSES,
  INITIAL_ATTENDANCE,
  INITIAL_EXAMS,
  INITIAL_MARKS,
  INITIAL_FEES,
  INITIAL_TIMETABLE,
  INITIAL_NOTIFICATIONS
} from '../data/initialData';

interface SMSContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  currentUserId: string;
  setCurrentUserId: (id: string) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;

  // Data Collections
  students: Student[];
  teachers: Teacher[];
  courses: Course[];
  attendance: AttendanceRecord[];
  exams: Exam[];
  marks: StudentMark[];
  fees: FeeRecord[];
  timetable: TimetableSlot[];
  notifications: Notification[];

  // Student Actions
  addStudent: (student: Omit<Student, 'id' | 'rollNo'>) => Student;
  updateStudent: (id: string, student: Partial<Student>) => void;
  deleteStudent: (id: string) => void;

  // Teacher Actions
  addTeacher: (teacher: Omit<Teacher, 'id'>) => Teacher;
  updateTeacher: (id: string, teacher: Partial<Teacher>) => void;
  deleteTeacher: (id: string) => void;

  // Course Actions
  addCourse: (course: Course) => void;
  updateCourse: (id: string, course: Partial<Course>) => void;
  deleteCourse: (id: string) => void;

  // Attendance Actions
  saveAttendance: (courseId: string, date: string, records: { studentId: string; status: 'Present' | 'Absent' | 'Late'; remarks?: string }[]) => void;

  // Exams & Marks
  addExam: (exam: Exam) => void;
  saveStudentMarks: (marks: StudentMark[]) => void;

  // Fees
  recordFeePayment: (feeId: string, amount: number, method: 'UPI' | 'Online Banking' | 'Cash' | 'Card' | 'Cheque') => void;
  addFeeInvoice: (invoice: FeeRecord) => void;

  // Timetable
  addTimetableSlot: (slot: Omit<TimetableSlot, 'id'>) => void;
  deleteTimetableSlot: (id: string) => void;

  // Notifications
  addNotification: (notif: Omit<Notification, 'id' | 'date'>) => void;
  deleteNotification: (id: string) => void;

  // Database Management
  exportDatabaseJSON: () => void;
  importDatabaseJSON: (jsonData: string) => boolean;
  resetDatabase: () => void;
}

const SMSContext = createContext<SMSContextType | undefined>(undefined);

const STORAGE_KEYS = {
  STUDENTS: 'sms_data_students_v1',
  TEACHERS: 'sms_data_teachers_v1',
  COURSES: 'sms_data_courses_v1',
  ATTENDANCE: 'sms_data_attendance_v1',
  EXAMS: 'sms_data_exams_v1',
  MARKS: 'sms_data_marks_v1',
  FEES: 'sms_data_fees_v1',
  TIMETABLE: 'sms_data_timetable_v1',
  NOTIFICATIONS: 'sms_data_notifications_v1',
  ROLE: 'sms_user_role_v1',
  USER_ID: 'sms_current_user_id_v1'
};

function loadStorage<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (saved) return JSON.parse(saved);
  } catch (err) {
    console.error(`Error loading key ${key}:`, err);
  }
  return fallback;
}

export const SMSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<UserRole>(() => loadStorage(STORAGE_KEYS.ROLE, 'admin'));
  const [currentUserId, setCurrentUserIdState] = useState<string>(() => loadStorage(STORAGE_KEYS.USER_ID, 'ADMIN-ROOT'));
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  const [students, setStudents] = useState<Student[]>(() => loadStorage(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS));
  const [teachers, setTeachers] = useState<Teacher[]>(() => loadStorage(STORAGE_KEYS.TEACHERS, INITIAL_TEACHERS));
  const [courses, setCourses] = useState<Course[]>(() => loadStorage(STORAGE_KEYS.COURSES, INITIAL_COURSES));
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => loadStorage(STORAGE_KEYS.ATTENDANCE, INITIAL_ATTENDANCE));
  const [exams, setExams] = useState<Exam[]>(() => loadStorage(STORAGE_KEYS.EXAMS, INITIAL_EXAMS));
  const [marks, setMarks] = useState<StudentMark[]>(() => loadStorage(STORAGE_KEYS.MARKS, INITIAL_MARKS));
  const [fees, setFees] = useState<FeeRecord[]>(() => loadStorage(STORAGE_KEYS.FEES, INITIAL_FEES));
  const [timetable, setTimetable] = useState<TimetableSlot[]>(() => loadStorage(STORAGE_KEYS.TIMETABLE, INITIAL_TIMETABLE));
  const [notifications, setNotifications] = useState<Notification[]>(() => loadStorage(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS));

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE, JSON.stringify(role));
  }, [role]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER_ID, JSON.stringify(currentUserId));
  }, [currentUserId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TEACHERS, JSON.stringify(teachers));
  }, [teachers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EXAMS, JSON.stringify(exams));
  }, [exams]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MARKS, JSON.stringify(marks));
  }, [marks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FEES, JSON.stringify(fees));
  }, [fees]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TIMETABLE, JSON.stringify(timetable));
  }, [timetable]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    if (newRole === 'admin') {
      setCurrentUserIdState('ADMIN-ROOT');
    } else if (newRole === 'teacher') {
      setCurrentUserIdState(teachers[0]?.id || 'FAC-101');
    } else if (newRole === 'student') {
      setCurrentUserIdState(students[0]?.id || 'STU-2025-001');
    }
  };

  const setCurrentUserId = (id: string) => {
    setCurrentUserIdState(id);
  };

  // Student Actions
  const addStudent = (newStu: Omit<Student, 'id' | 'rollNo'>): Student => {
    const nextSeq = students.length + 1;
    const padded = String(nextSeq).padStart(3, '0');
    const id = `STU-2025-${padded}`;
    const deptPrefix = newStu.department.includes('Electronics')
      ? 'EC'
      : newStu.department.includes('Mechanical')
      ? 'ME'
      : newStu.department.includes('Information')
      ? 'IT'
      : 'CS';
    const rollNo = `${deptPrefix}25B${padded}`;

    const student: Student = {
      ...newStu,
      id,
      rollNo
    };

    setStudents((prev) => [student, ...prev]);

    // Also auto-generate initial fee record for odd semester
    const newFeeRecord: FeeRecord = {
      id: `FEE-2025-${padded}`,
      studentId: id,
      academicYear: '2025-2026',
      semester: newStu.semester,
      totalAmount: 65000,
      paidAmount: 0,
      dueDate: '2025-10-30',
      status: 'Pending',
      breakdown: {
        tuition: 45000,
        lab: 10000,
        library: 3000,
        examination: 4000,
        other: 3000
      },
      transactions: []
    };
    setFees((prev) => [...prev, newFeeRecord]);

    return student;
  };

  const updateStudent = (id: string, updatedFields: Partial<Student>) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updatedFields } : s))
    );
  };

  const deleteStudent = (id: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== id));
  };

  // Teacher Actions
  const addTeacher = (teacherData: Omit<Teacher, 'id'>): Teacher => {
    const nextSeq = teachers.length + 101;
    const id = `FAC-${nextSeq}`;
    const newTeacher: Teacher = {
      ...teacherData,
      id
    };
    setTeachers((prev) => [...prev, newTeacher]);
    return newTeacher;
  };

  const updateTeacher = (id: string, updatedFields: Partial<Teacher>) => {
    setTeachers((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updatedFields } : t))
    );
  };

  const deleteTeacher = (id: string) => {
    setTeachers((prev) => prev.filter((t) => t.id !== id));
  };

  // Course Actions
  const addCourse = (course: Course) => {
    setCourses((prev) => [...prev, course]);
  };

  const updateCourse = (id: string, updated: Partial<Course>) => {
    setCourses((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updated } : c))
    );
  };

  const deleteCourse = (id: string) => {
    setCourses((prev) => prev.filter((c) => c.id !== id));
  };

  // Attendance Actions
  const saveAttendance = (
    courseId: string,
    date: string,
    records: { studentId: string; status: 'Present' | 'Absent' | 'Late'; remarks?: string }[]
  ) => {
    setAttendance((prev) => {
      const existingIdx = prev.findIndex((a) => a.courseId === courseId && a.date === date);
      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx] = {
          ...copy[existingIdx],
          records
        };
        return copy;
      } else {
        const newRecord: AttendanceRecord = {
          id: `ATT-${date}-${courseId}`,
          courseId,
          date,
          records
        };
        return [newRecord, ...prev];
      }
    });
  };

  // Exam & Marks
  const addExam = (exam: Exam) => {
    setExams((prev) => [...prev, exam]);
  };

  const saveStudentMarks = (newMarks: StudentMark[]) => {
    setMarks((prev) => {
      const updated = [...prev];
      newMarks.forEach((m) => {
        const idx = updated.findIndex((item) => item.examId === m.examId && item.studentId === m.studentId);
        if (idx >= 0) {
          updated[idx] = m;
        } else {
          updated.push(m);
        }
      });
      return updated;
    });
  };

  // Fees
  const recordFeePayment = (
    feeId: string,
    amount: number,
    method: 'UPI' | 'Online Banking' | 'Cash' | 'Card' | 'Cheque'
  ) => {
    setFees((prev) =>
      prev.map((f) => {
        if (f.id === feeId) {
          const newPaid = Math.min(f.totalAmount, f.paidAmount + amount);
          const newStatus =
            newPaid >= f.totalAmount
              ? 'Paid'
              : newPaid > 0
              ? 'Partial'
              : f.status === 'Overdue'
              ? 'Overdue'
              : 'Pending';

          const newTx = {
            txId: `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
            date: new Date().toISOString().split('T')[0],
            amount,
            method
          };

          return {
            ...f,
            paidAmount: newPaid,
            status: newStatus,
            transactions: [newTx, ...f.transactions]
          };
        }
        return f;
      })
    );
  };

  const addFeeInvoice = (invoice: FeeRecord) => {
    setFees((prev) => [invoice, ...prev]);
  };

  // Timetable
  const addTimetableSlot = (slot: Omit<TimetableSlot, 'id'>) => {
    const id = `TT-${Date.now()}`;
    setTimetable((prev) => [...prev, { ...slot, id }]);
  };

  const deleteTimetableSlot = (id: string) => {
    setTimetable((prev) => prev.filter((t) => t.id !== id));
  };

  // Notifications
  const addNotification = (notif: Omit<Notification, 'id' | 'date'>) => {
    const newNotif: Notification = {
      ...notif,
      id: `NOTIF-${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  // Database Management
  const exportDatabaseJSON = () => {
    const snapshot = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      institution: 'Apex Institute of Engineering & Technology',
      data: {
        students,
        teachers,
        courses,
        attendance,
        exams,
        marks,
        fees,
        timetable,
        notifications
      }
    };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `student_management_system_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const importDatabaseJSON = (jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed.data) {
        if (Array.isArray(parsed.data.students)) setStudents(parsed.data.students);
        if (Array.isArray(parsed.data.teachers)) setTeachers(parsed.data.teachers);
        if (Array.isArray(parsed.data.courses)) setCourses(parsed.data.courses);
        if (Array.isArray(parsed.data.attendance)) setAttendance(parsed.data.attendance);
        if (Array.isArray(parsed.data.exams)) setExams(parsed.data.exams);
        if (Array.isArray(parsed.data.marks)) setMarks(parsed.data.marks);
        if (Array.isArray(parsed.data.fees)) setFees(parsed.data.fees);
        if (Array.isArray(parsed.data.timetable)) setTimetable(parsed.data.timetable);
        if (Array.isArray(parsed.data.notifications)) setNotifications(parsed.data.notifications);
        return true;
      }
    } catch (e) {
      console.error('Import error:', e);
    }
    return false;
  };

  const resetDatabase = () => {
    setStudents(INITIAL_STUDENTS);
    setTeachers(INITIAL_TEACHERS);
    setCourses(INITIAL_COURSES);
    setAttendance(INITIAL_ATTENDANCE);
    setExams(INITIAL_EXAMS);
    setMarks(INITIAL_MARKS);
    setFees(INITIAL_FEES);
    setTimetable(INITIAL_TIMETABLE);
    setNotifications(INITIAL_NOTIFICATIONS);
    localStorage.clear();
  };

  return (
    <SMSContext.Provider
      value={{
        role,
        setRole,
        currentUserId,
        setCurrentUserId,
        activeTab,
        setActiveTab,
        students,
        teachers,
        courses,
        attendance,
        exams,
        marks,
        fees,
        timetable,
        notifications,
        addStudent,
        updateStudent,
        deleteStudent,
        addTeacher,
        updateTeacher,
        deleteTeacher,
        addCourse,
        updateCourse,
        deleteCourse,
        saveAttendance,
        addExam,
        saveStudentMarks,
        recordFeePayment,
        addFeeInvoice,
        addTimetableSlot,
        deleteTimetableSlot,
        addNotification,
        deleteNotification,
        exportDatabaseJSON,
        importDatabaseJSON,
        resetDatabase
      }}
    >
      {children}
    </SMSContext.Provider>
  );
};

export const useSMS = () => {
  const context = useContext(SMSContext);
  if (!context) {
    throw new Error('useSMS must be used within an SMSProvider');
  }
  return context;
};
