import React from 'react';
import { SMSProvider, useSMS } from './context/SMSContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardModule } from './components/modules/DashboardModule';
import { StudentRegistrationModule } from './components/modules/StudentRegistrationModule';
import { TeacherModule } from './components/modules/TeacherModule';
import { CourseModule } from './components/modules/CourseModule';
import { AttendanceModule } from './components/modules/AttendanceModule';
import { ExaminationModule } from './components/modules/ExaminationModule';
import { FeeModule } from './components/modules/FeeModule';
import { TimetableModule } from './components/modules/TimetableModule';
import { ReportModule } from './components/modules/ReportModule';
import { NotificationModule } from './components/modules/NotificationModule';
import { DatabaseModule } from './components/modules/DatabaseModule';

const MainContent: React.FC = () => {
  const { activeTab } = useSMS();

  const renderModule = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardModule />;
      case 'students':
        return <StudentRegistrationModule />;
      case 'teachers':
        return <TeacherModule />;
      case 'courses':
        return <CourseModule />;
      case 'attendance':
        return <AttendanceModule />;
      case 'exams':
        return <ExaminationModule />;
      case 'fees':
        return <FeeModule />;
      case 'timetable':
        return <TimetableModule />;
      case 'reports':
        return <ReportModule />;
      case 'notifications':
        return <NotificationModule />;
      case 'database':
        return <DatabaseModule />;
      default:
        return <DashboardModule />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900">
      <Header />
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {renderModule()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <SMSProvider>
      <MainContent />
    </SMSProvider>
  );
}
