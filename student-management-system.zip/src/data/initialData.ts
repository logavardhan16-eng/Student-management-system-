import { Student, Teacher, Course, AttendanceRecord, Exam, StudentMark, FeeRecord, TimetableSlot, Notification } from '../types';

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'STU-2025-001',
    firstName: 'Aarav',
    lastName: 'Sharma',
    email: 'aarav.sharma@campus.edu',
    phone: '+91 98765 43210',
    dob: '2004-05-14',
    gender: 'Male',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech',
    semester: 5,
    batch: '2023-2027',
    rollNo: 'CS23B001',
    address: '42 Orchid Park, Sector 15, Tech City',
    bloodGroup: 'O+',
    guardianName: 'Rajesh Sharma',
    guardianPhone: '+91 98765 11111',
    enrollmentDate: '2023-08-01',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'STU-2025-002',
    firstName: 'Priya',
    lastName: 'Nair',
    email: 'priya.nair@campus.edu',
    phone: '+91 98765 43211',
    dob: '2004-09-22',
    gender: 'Female',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech',
    semester: 5,
    batch: '2023-2027',
    rollNo: 'CS23B002',
    address: '18 Palm Grove, Lake View Road',
    bloodGroup: 'B+',
    guardianName: 'Suresh Nair',
    guardianPhone: '+91 98765 22222',
    enrollmentDate: '2023-08-01',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'STU-2025-003',
    firstName: 'Rohan',
    lastName: 'Verma',
    email: 'rohan.verma@campus.edu',
    phone: '+91 98765 43212',
    dob: '2004-11-08',
    gender: 'Male',
    department: 'Electronics & Communication',
    degree: 'B.Tech',
    semester: 3,
    batch: '2024-2028',
    rollNo: 'EC24B015',
    address: '102 Green Heights, Metro Station Rd',
    bloodGroup: 'A+',
    guardianName: 'Manoj Verma',
    guardianPhone: '+91 98765 33333',
    enrollmentDate: '2024-08-05',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'STU-2025-004',
    firstName: 'Ananya',
    lastName: 'Deshmukh',
    email: 'ananya.d@campus.edu',
    phone: '+91 98765 43213',
    dob: '2004-03-19',
    gender: 'Female',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech',
    semester: 5,
    batch: '2023-2027',
    rollNo: 'CS23B004',
    address: '77 Cyber Enclave, IT Corridor',
    bloodGroup: 'AB+',
    guardianName: 'Anil Deshmukh',
    guardianPhone: '+91 98765 44444',
    enrollmentDate: '2023-08-01',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'STU-2025-005',
    firstName: 'Kavita',
    lastName: 'Patel',
    email: 'kavita.patel@campus.edu',
    phone: '+91 98765 43214',
    dob: '2003-12-30',
    gender: 'Female',
    department: 'Information Technology',
    degree: 'B.Tech',
    semester: 7,
    batch: '2022-2026',
    rollNo: 'IT22B009',
    address: '15 Diamond Avenue, Heritage Colony',
    bloodGroup: 'O-',
    guardianName: 'Dinesh Patel',
    guardianPhone: '+91 98765 55555',
    enrollmentDate: '2022-08-10',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'STU-2025-006',
    firstName: 'Dev',
    lastName: 'Singhania',
    email: 'dev.singhania@campus.edu',
    phone: '+91 98765 43215',
    dob: '2004-07-02',
    gender: 'Male',
    department: 'Mechanical Engineering',
    degree: 'B.Tech',
    semester: 3,
    batch: '2024-2028',
    rollNo: 'ME24B022',
    address: '89 Industrial Area, Phase 2',
    bloodGroup: 'B-',
    guardianName: 'Vikas Singhania',
    guardianPhone: '+91 98765 66666',
    enrollmentDate: '2024-08-05',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_TEACHERS: Teacher[] = [
  {
    id: 'FAC-101',
    name: 'Dr. Evelyn Reed',
    email: 'evelyn.reed@campus.edu',
    phone: '+91 91234 56780',
    department: 'Computer Science & Engineering',
    designation: 'Professor & Head of Department',
    qualification: 'Ph.D. in Artificial Intelligence (IIT Delhi)',
    joiningDate: '2016-06-15',
    assignedCourses: ['CS301', 'CS305'],
    officeRoom: 'Block A, Room 302',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'FAC-102',
    name: 'Prof. Marcus Vance',
    email: 'marcus.vance@campus.edu',
    phone: '+91 91234 56781',
    department: 'Computer Science & Engineering',
    designation: 'Associate Professor',
    qualification: 'M.Tech in Distributed Database Systems',
    joiningDate: '2019-01-10',
    assignedCourses: ['CS302'],
    officeRoom: 'Block A, Room 308',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'FAC-103',
    name: 'Dr. Sunita Kulkarni',
    email: 'sunita.k@campus.edu',
    phone: '+91 91234 56782',
    department: 'Electronics & Communication',
    designation: 'Associate Professor',
    qualification: 'Ph.D. in VLSI & Signal Processing',
    joiningDate: '2018-07-20',
    assignedCourses: ['EC201'],
    officeRoom: 'Block B, Room 204',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'FAC-104',
    name: 'Prof. Alan Miller',
    email: 'alan.miller@campus.edu',
    phone: '+91 91234 56783',
    department: 'Mechanical Engineering',
    designation: 'Assistant Professor',
    qualification: 'M.E. in Thermodynamics & Fluid Dynamics',
    joiningDate: '2021-09-01',
    assignedCourses: ['ME201'],
    officeRoom: 'Block C, Room 105',
    status: 'Active',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'CS301',
    name: 'Data Structures & Algorithms',
    code: 'CS301',
    department: 'Computer Science & Engineering',
    semester: 5,
    credits: 4,
    instructorId: 'FAC-101',
    instructorName: 'Dr. Evelyn Reed',
    capacity: 60,
    enrolledCount: 3,
    description: 'Advanced trees, graphs, dynamic programming, sorting and computational complexity.',
    schedule: 'Mon, Wed, Fri (09:00 - 10:00 AM)',
    room: 'LH-101'
  },
  {
    id: 'CS302',
    name: 'Database Management Systems',
    code: 'CS302',
    department: 'Computer Science & Engineering',
    semester: 5,
    credits: 4,
    instructorId: 'FAC-102',
    instructorName: 'Prof. Marcus Vance',
    capacity: 60,
    enrolledCount: 3,
    description: 'Relational model, SQL, normalization, concurrency control, indexing and transactions.',
    schedule: 'Tue, Thu (10:00 - 11:30 AM)',
    room: 'LH-102'
  },
  {
    id: 'CS305',
    name: 'Computer Networks & Security',
    code: 'CS305',
    department: 'Computer Science & Engineering',
    semester: 5,
    credits: 3,
    instructorId: 'FAC-101',
    instructorName: 'Dr. Evelyn Reed',
    capacity: 55,
    enrolledCount: 3,
    description: 'OSI & TCP/IP stack, routing algorithms, socket programming, SSL/TLS, and network defense.',
    schedule: 'Mon, Thu (02:00 - 03:30 PM)',
    room: 'LH-105'
  },
  {
    id: 'EC201',
    name: 'Digital Electronics & Logic Gates',
    code: 'EC201',
    department: 'Electronics & Communication',
    semester: 3,
    credits: 4,
    instructorId: 'FAC-103',
    instructorName: 'Dr. Sunita Kulkarni',
    capacity: 50,
    enrolledCount: 1,
    description: 'Boolean algebra, combinational circuits, flip-flops, sequential design, and counters.',
    schedule: 'Mon, Wed (11:00 AM - 12:30 PM)',
    room: 'EC-Lab 1'
  },
  {
    id: 'ME201',
    name: 'Engineering Thermodynamics',
    code: 'ME201',
    department: 'Mechanical Engineering',
    semester: 3,
    credits: 3,
    instructorId: 'FAC-104',
    instructorName: 'Prof. Alan Miller',
    capacity: 45,
    enrolledCount: 1,
    description: 'First and second laws of thermodynamics, Carnot cycle, entropy, and heat engines.',
    schedule: 'Tue, Fri (01:00 - 02:30 PM)',
    room: 'ME-201'
  }
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  {
    id: 'ATT-2025-09-15-CS301',
    courseId: 'CS301',
    date: '2025-09-15',
    records: [
      { studentId: 'STU-2025-001', status: 'Present' },
      { studentId: 'STU-2025-002', status: 'Present' },
      { studentId: 'STU-2025-004', status: 'Late', remarks: 'Joined 10 mins late' }
    ]
  },
  {
    id: 'ATT-2025-09-16-CS301',
    courseId: 'CS301',
    date: '2025-09-16',
    records: [
      { studentId: 'STU-2025-001', status: 'Present' },
      { studentId: 'STU-2025-002', status: 'Present' },
      { studentId: 'STU-2025-004', status: 'Present' }
    ]
  },
  {
    id: 'ATT-2025-09-17-CS301',
    courseId: 'CS301',
    date: '2025-09-17',
    records: [
      { studentId: 'STU-2025-001', status: 'Absent', remarks: 'Medical leave' },
      { studentId: 'STU-2025-002', status: 'Present' },
      { studentId: 'STU-2025-004', status: 'Present' }
    ]
  },
  {
    id: 'ATT-2025-09-15-CS302',
    courseId: 'CS302',
    date: '2025-09-15',
    records: [
      { studentId: 'STU-2025-001', status: 'Present' },
      { studentId: 'STU-2025-002', status: 'Present' },
      { studentId: 'STU-2025-004', status: 'Absent' }
    ]
  }
];

export const INITIAL_EXAMS: Exam[] = [
  {
    id: 'EXAM-01',
    name: 'Midterm Examination 2025',
    courseId: 'CS301',
    courseName: 'Data Structures & Algorithms',
    semester: 5,
    examDate: '2025-10-10',
    maxMarks: 100,
    passMarks: 40,
    weightage: 30
  },
  {
    id: 'EXAM-02',
    name: 'Midterm Examination 2025',
    courseId: 'CS302',
    courseName: 'Database Management Systems',
    semester: 5,
    examDate: '2025-10-12',
    maxMarks: 100,
    passMarks: 40,
    weightage: 30
  },
  {
    id: 'EXAM-03',
    name: 'Practical Lab Assessment',
    courseId: 'CS305',
    courseName: 'Computer Networks & Security',
    semester: 5,
    examDate: '2025-10-15',
    maxMarks: 50,
    passMarks: 20,
    weightage: 20
  }
];

export const INITIAL_MARKS: StudentMark[] = [
  {
    id: 'MRK-101',
    examId: 'EXAM-01',
    studentId: 'STU-2025-001',
    courseId: 'CS301',
    marksObtained: 88,
    grade: 'A+',
    feedback: 'Outstanding problem solving in graph traversal algorithms.'
  },
  {
    id: 'MRK-102',
    examId: 'EXAM-01',
    studentId: 'STU-2025-002',
    courseId: 'CS301',
    marksObtained: 94,
    grade: 'A+',
    feedback: 'Flawless dynamic programming proofs.'
  },
  {
    id: 'MRK-103',
    examId: 'EXAM-01',
    studentId: 'STU-2025-004',
    courseId: 'CS301',
    marksObtained: 72,
    grade: 'B+',
    feedback: 'Good implementation, practice tree re-balancing.'
  },
  {
    id: 'MRK-104',
    examId: 'EXAM-02',
    studentId: 'STU-2025-001',
    courseId: 'CS302',
    marksObtained: 82,
    grade: 'A',
    feedback: 'Solid SQL query optimization and schema design.'
  },
  {
    id: 'MRK-105',
    examId: 'EXAM-02',
    studentId: 'STU-2025-002',
    courseId: 'CS302',
    marksObtained: 90,
    grade: 'A+',
    feedback: 'Excellent normalization concepts.'
  },
  {
    id: 'MRK-106',
    examId: 'EXAM-02',
    studentId: 'STU-2025-004',
    courseId: 'CS302',
    marksObtained: 68,
    grade: 'B',
    feedback: 'Needs revision on transaction isolation levels.'
  }
];

export const INITIAL_FEES: FeeRecord[] = [
  {
    id: 'FEE-2025-001',
    studentId: 'STU-2025-001',
    academicYear: '2025-2026',
    semester: 5,
    totalAmount: 65000,
    paidAmount: 65000,
    dueDate: '2025-09-30',
    status: 'Paid',
    breakdown: {
      tuition: 45000,
      lab: 10000,
      library: 3000,
      examination: 4000,
      other: 3000
    },
    transactions: [
      {
        txId: 'TXN-984210',
        date: '2025-08-20',
        amount: 65000,
        method: 'UPI'
      }
    ]
  },
  {
    id: 'FEE-2025-002',
    studentId: 'STU-2025-002',
    academicYear: '2025-2026',
    semester: 5,
    totalAmount: 65000,
    paidAmount: 35000,
    dueDate: '2025-09-30',
    status: 'Partial',
    breakdown: {
      tuition: 45000,
      lab: 10000,
      library: 3000,
      examination: 4000,
      other: 3000
    },
    transactions: [
      {
        txId: 'TXN-984255',
        date: '2025-08-28',
        amount: 35000,
        method: 'Online Banking'
      }
    ]
  },
  {
    id: 'FEE-2025-003',
    studentId: 'STU-2025-003',
    academicYear: '2025-2026',
    semester: 3,
    totalAmount: 62000,
    paidAmount: 0,
    dueDate: '2025-09-15',
    status: 'Overdue',
    breakdown: {
      tuition: 43000,
      lab: 9000,
      library: 3000,
      examination: 4000,
      other: 3000
    },
    transactions: []
  },
  {
    id: 'FEE-2025-004',
    studentId: 'STU-2025-004',
    academicYear: '2025-2026',
    semester: 5,
    totalAmount: 65000,
    paidAmount: 0,
    dueDate: '2025-10-15',
    status: 'Pending',
    breakdown: {
      tuition: 45000,
      lab: 10000,
      library: 3000,
      examination: 4000,
      other: 3000
    },
    transactions: []
  }
];

export const INITIAL_TIMETABLE: TimetableSlot[] = [
  {
    id: 'TT-01',
    day: 'Monday',
    timeSlot: '09:00 - 10:00 AM',
    courseId: 'CS301',
    courseName: 'Data Structures & Algorithms',
    teacherId: 'FAC-101',
    teacherName: 'Dr. Evelyn Reed',
    room: 'LH-101',
    semester: 5,
    department: 'Computer Science & Engineering'
  },
  {
    id: 'TT-02',
    day: 'Monday',
    timeSlot: '11:00 - 12:00 PM',
    courseId: 'CS302',
    courseName: 'Database Management Systems',
    teacherId: 'FAC-102',
    teacherName: 'Prof. Marcus Vance',
    room: 'LH-102',
    semester: 5,
    department: 'Computer Science & Engineering'
  },
  {
    id: 'TT-03',
    day: 'Tuesday',
    timeSlot: '10:00 - 11:30 AM',
    courseId: 'CS302',
    courseName: 'Database Management Systems',
    teacherId: 'FAC-102',
    teacherName: 'Prof. Marcus Vance',
    room: 'LH-102',
    semester: 5,
    department: 'Computer Science & Engineering'
  },
  {
    id: 'TT-04',
    day: 'Wednesday',
    timeSlot: '09:00 - 10:00 AM',
    courseId: 'CS301',
    courseName: 'Data Structures & Algorithms',
    teacherId: 'FAC-101',
    teacherName: 'Dr. Evelyn Reed',
    room: 'LH-101',
    semester: 5,
    department: 'Computer Science & Engineering'
  },
  {
    id: 'TT-05',
    day: 'Thursday',
    timeSlot: '02:00 - 03:30 PM',
    courseId: 'CS305',
    courseName: 'Computer Networks & Security',
    teacherId: 'FAC-101',
    teacherName: 'Dr. Evelyn Reed',
    room: 'LH-105',
    semester: 5,
    department: 'Computer Science & Engineering'
  },
  {
    id: 'TT-06',
    day: 'Friday',
    timeSlot: '09:00 - 10:00 AM',
    courseId: 'CS301',
    courseName: 'Data Structures & Algorithms',
    teacherId: 'FAC-101',
    teacherName: 'Dr. Evelyn Reed',
    room: 'LH-101',
    semester: 5,
    department: 'Computer Science & Engineering'
  }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'NOTIF-01',
    title: 'Midterm Examination Schedule Released - Fall 2025',
    content: 'The Midterm Exam timetable for Semesters 3, 5, and 7 has been published. All students are requested to review room allocations and bring their official Student ID cards.',
    category: 'Exam',
    targetAudience: 'All',
    date: '2025-09-16',
    isImportant: true,
    author: 'Office of the Controller of Examinations'
  },
  {
    id: 'NOTIF-02',
    title: 'Semester Tuition Fee Deadline Reminder',
    content: 'Students with outstanding dues for Odd Semester 2025-2026 must complete payments before September 30 to avoid a late clearance fee and examination hall ticket hold.',
    category: 'Fee',
    targetAudience: 'Students',
    date: '2025-09-14',
    isImportant: true,
    author: 'Accounts & Finance Department'
  },
  {
    id: 'NOTIF-03',
    title: 'Annual Technical Symposium: HackCampus 2025',
    content: 'Registrations are now open for the 48-hour inter-college hackathon HackCampus 2025. Tracks include Generative AI, Cloud Systems, and IoT Automation.',
    category: 'Academic',
    targetAudience: 'All',
    date: '2025-09-12',
    isImportant: false,
    author: 'CSE Department Student Council'
  },
  {
    id: 'NOTIF-04',
    title: 'Faculty Academic Council Meeting',
    content: 'All faculty members are invited to attend the quarterly syllabus review meeting this Friday at 3:30 PM in Conference Room A.',
    category: 'General',
    targetAudience: 'Teachers',
    date: '2025-09-10',
    isImportant: false,
    author: 'Dean of Academics'
  }
];
