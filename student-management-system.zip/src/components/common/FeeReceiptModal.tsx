import React from 'react';
import { FeeRecord, Student } from '../../types';
import { X, Printer, Receipt, CheckCircle2, Building2 } from 'lucide-react';

interface FeeReceiptModalProps {
  feeRecord: FeeRecord | null;
  student: Student | null;
  onClose: () => void;
}

export const FeeReceiptModal: React.FC<FeeReceiptModalProps> = ({
  feeRecord,
  student,
  onClose
}) => {
  if (!feeRecord || !student) return null;

  const latestTx = feeRecord.transactions[0] || {
    txId: 'TXN-DIRECT-OFFICE',
    date: new Date().toISOString().split('T')[0],
    amount: feeRecord.paidAmount,
    method: 'Cash / Direct Transfer'
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-600" />
            <h3 className="font-semibold text-slate-800 text-sm">Official Fee Payment Receipt</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Canvas */}
        <div className="p-6 bg-slate-50/50">
          <div
            id="printable-fee-receipt"
            className="bg-white p-6 rounded-xl border border-slate-300 shadow-sm relative"
          >
            {/* Stamp if paid */}
            {feeRecord.paidAmount > 0 && (
              <div className="absolute right-8 top-20 rotate-[-12deg] pointer-events-none opacity-80 border-2 border-emerald-600 text-emerald-700 px-3 py-1 rounded font-black text-sm tracking-widest uppercase flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                {feeRecord.status === 'Paid' ? 'PAID IN FULL' : 'PARTIAL RECEIVED'}
              </div>
            )}

            {/* Institution Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
                  <Building2 className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900 text-sm uppercase">Apex Institute of Technology</h2>
                  <p className="text-[11px] text-slate-500">Finance & Student Accounts Department</p>
                </div>
              </div>
              <div className="text-right text-xs">
                <p className="font-mono font-bold text-slate-800">#{feeRecord.id}</p>
                <p className="text-slate-500 text-[11px]">Date: {latestTx.date}</p>
              </div>
            </div>

            {/* Student Particulars */}
            <div className="grid grid-cols-2 gap-3 my-4 p-3 bg-slate-50 rounded-lg text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">STUDENT NAME</span>
                <span className="font-bold text-slate-800">{student.firstName} {student.lastName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">ROLL NUMBER</span>
                <span className="font-bold text-slate-800 font-mono">{student.rollNo}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">DEPARTMENT & SEMESTER</span>
                <span className="font-medium text-slate-700">{student.department} (Sem {feeRecord.semester})</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">ACADEMIC SESSION</span>
                <span className="font-medium text-slate-700">{feeRecord.academicYear}</span>
              </div>
            </div>

            {/* Itemized Fee Breakdown Table */}
            <div className="my-4">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2">Fee Head / Description</th>
                    <th className="py-2 text-right">Amount (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  <tr>
                    <td className="py-1.5">Academic Tuition & Instruction Fee</td>
                    <td className="py-1.5 text-right font-medium">₹{feeRecord.breakdown.tuition.toLocaleString()}</td>
                  </tr>
                  <tr>
                    <td className="py-1.5">Laboratory & Computing Equipment Fee</td>
                    <td className="py-1.5 text-right font-medium">₹{feeRecord.breakdown.lab.toLocaleString()}</td>
                  </tr>
                  <tr>
                    <td className="py-1.5">Central Digital Library & Journal Access</td>
                    <td className="py-1.5 text-right font-medium">₹{feeRecord.breakdown.library.toLocaleString()}</td>
                  </tr>
                  <tr>
                    <td className="py-1.5">University Examination & Assessment Fee</td>
                    <td className="py-1.5 text-right font-medium">₹{feeRecord.breakdown.examination.toLocaleString()}</td>
                  </tr>
                  <tr>
                    <td className="py-1.5">Sports, Amenities & Student Welfare</td>
                    <td className="py-1.5 text-right font-medium">₹{feeRecord.breakdown.other.toLocaleString()}</td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-slate-300 font-semibold text-slate-800">
                    <td className="pt-2">Total Payable Amount</td>
                    <td className="pt-2 text-right font-mono">₹{feeRecord.totalAmount.toLocaleString()}</td>
                  </tr>
                  <tr className="text-emerald-700 font-bold">
                    <td className="py-1">Total Amount Cleared</td>
                    <td className="py-1 text-right font-mono">₹{feeRecord.paidAmount.toLocaleString()}</td>
                  </tr>
                  <tr className="text-slate-500 font-medium">
                    <td className="py-1">Balance Due Outstanding</td>
                    <td className="py-1 text-right font-mono">₹{(feeRecord.totalAmount - feeRecord.paidAmount).toLocaleString()}</td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Payment Mode & Transaction Ref */}
            <div className="p-3 bg-slate-50 rounded-lg text-xs border border-slate-200 flex justify-between items-center">
              <div>
                <p className="text-[10px] text-slate-400">TRANSACTION ID / METHOD</p>
                <p className="font-mono font-medium text-slate-800">{latestTx.txId} • {latestTx.method}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-slate-400">RECEIPT STATUS</p>
                <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  feeRecord.status === 'Paid'
                    ? 'bg-emerald-100 text-emerald-800'
                    : feeRecord.status === 'Partial'
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {feeRecord.status.toUpperCase()}
                </span>
              </div>
            </div>

            {/* Signature & Disclaimer */}
            <div className="mt-8 pt-4 border-t border-slate-200 flex justify-between items-end text-[11px] text-slate-500">
              <p>This is a computer-generated receipt valid without a physical seal.</p>
              <div className="text-center">
                <div className="w-28 border-b border-slate-300 mb-1 pb-1 font-mono text-[9px]">ACCOUNTS OFFICER</div>
                <span className="font-semibold text-slate-700">Authorized Signature</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">Receipt Ref: {feeRecord.id}</span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded-lg transition"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Official Receipt
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
