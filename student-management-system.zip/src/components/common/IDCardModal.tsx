import React from 'react';
import { Student } from '../../types';
import { X, Printer, QrCode, ShieldCheck, GraduationCap } from 'lucide-react';

interface IDCardModalProps {
  student: Student | null;
  onClose: () => void;
}

export const IDCardModal: React.FC<IDCardModalProps> = ({ student, onClose }) => {
  if (!student) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-indigo-600" />
            <h3 className="font-semibold text-slate-800 text-sm">Official Student ID Card</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* The Printable ID Card */}
        <div className="p-6 flex flex-col items-center">
          <div
            id="printable-id-card"
            className="w-full max-w-[340px] bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 shadow-xl border border-indigo-500/30 relative overflow-hidden"
          >
            {/* Background watermark badge */}
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-indigo-500/10 rounded-full blur-xl pointer-events-none" />
            <div className="absolute -left-8 -bottom-8 w-32 h-32 bg-sky-500/10 rounded-full blur-xl pointer-events-none" />

            {/* Institution Header */}
            <div className="text-center pb-3 border-b border-indigo-400/20">
              <div className="flex items-center justify-center gap-1.5 mb-0.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span className="text-[11px] font-extrabold tracking-wider uppercase text-amber-300">
                  Apex Institute of Technology
                </span>
              </div>
              <p className="text-[9px] text-indigo-200 tracking-widest uppercase">
                Autonomous University • Est. 1998
              </p>
            </div>

            {/* Photo & Basic Details */}
            <div className="mt-4 flex flex-col items-center">
              <div className="relative">
                <div className="w-24 h-24 rounded-xl overflow-hidden border-2 border-amber-400 shadow-md bg-slate-800">
                  <img
                    src={student.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                    alt={`${student.firstName} ${student.lastName}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="absolute -bottom-2 -right-1 bg-emerald-500 text-[9px] font-bold px-1.5 py-0.5 rounded-full text-white border border-slate-900">
                  {student.status}
                </span>
              </div>

              <h4 className="mt-3 text-base font-bold text-white tracking-wide text-center">
                {student.firstName} {student.lastName}
              </h4>
              <p className="text-xs font-semibold text-amber-300">
                {student.rollNo}
              </p>
              <span className="mt-1 text-[10px] text-indigo-200 bg-indigo-900/60 px-2.5 py-0.5 rounded-full border border-indigo-700/50">
                {student.degree} - Semester {student.semester}
              </span>
            </div>

            {/* Detailed Key Attributes */}
            <div className="mt-4 space-y-1.5 text-[11px] bg-slate-800/60 p-3 rounded-xl border border-indigo-500/20">
              <div className="flex justify-between">
                <span className="text-slate-400">Department:</span>
                <span className="font-medium text-slate-200 text-right truncate max-w-[180px]">
                  {student.department}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Batch:</span>
                <span className="font-medium text-slate-200">{student.batch}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Blood Group:</span>
                <span className="font-bold text-red-400">{student.bloodGroup}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Emergency Contact:</span>
                <span className="font-medium text-slate-200">{student.guardianPhone}</span>
              </div>
            </div>

            {/* Barcode & QR Simulation */}
            <div className="mt-4 pt-3 border-t border-indigo-400/20 flex items-center justify-between">
              <div className="flex flex-col gap-1">
                {/* Simulated Barcode */}
                <div className="flex gap-[2px] items-center h-7 bg-white px-2 py-1 rounded">
                  {Array.from({ length: 28 }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-full bg-slate-900 ${
                        i % 3 === 0 ? 'w-[3px]' : i % 2 === 0 ? 'w-[1.5px]' : 'w-[1px]'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-[8px] text-center text-slate-400 font-mono tracking-wider">
                  {student.id}
                </span>
              </div>
              <div className="bg-white p-1 rounded-md text-slate-900">
                <QrCode className="w-9 h-9" />
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-500 mt-4 text-center">
            Valid across Campus Facilities, Digital Library & Laboratories.
          </p>
        </div>

        {/* Modal Actions */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">Card ID: {student.id}</span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded-lg transition"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition"
            >
              <Printer className="w-3.5 h-3.5" />
              Print ID Card
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
