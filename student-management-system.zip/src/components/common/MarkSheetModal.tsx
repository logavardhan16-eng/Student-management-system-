import React from 'react';
import { Student, StudentMark, Course, Exam } from '../../types';
import { X, Printer, Award, CheckCircle, GraduationCap } from 'lucide-react';

interface MarkSheetModalProps {
  student: Student | null;
  marks: StudentMark[];
  courses: Course[];
  exams: Exam[];
  onClose: () => void;
}

export const MarkSheetModal: React.FC<MarkSheetModalProps> = ({
  student,
  marks,
  courses,
  exams,
  onClose
}) => {
  if (!student) return null;

  const studentMarks = marks.filter((m) => m.studentId === student.id);

  // Calculate SGPA and Total
  const markItems = studentMarks.map((m) => {
    const course = courses.find((c) => c.id === m.courseId);
    const exam = exams.find((e) => e.id === m.examId);
    const credits = course?.credits || 3;
    let gradePoint = 10;
    if (m.grade === 'A+') gradePoint = 10;
    else if (m.grade === 'A') gradePoint = 9;
    else if (m.grade === 'B+') gradePoint = 8;
    else if (m.grade === 'B') gradePoint = 7;
    else if (m.grade === 'C') gradePoint = 6;
    else if (m.grade === 'D') gradePoint = 5;
    else gradePoint = 0;

    return {
      ...m,
      courseName: course?.name || m.courseId,
      courseCode: course?.code || m.courseId,
      examName: exam?.name || 'Semester Exam',
      maxMarks: exam?.maxMarks || 100,
      credits,
      gradePoint,
      creditPoints: credits * gradePoint
    };
  });

  const totalCredits = markItems.reduce((acc, item) => acc + item.credits, 0);
  const totalCreditPoints = markItems.reduce((acc, item) => acc + item.creditPoints, 0);
  const sgpa = totalCredits > 0 ? (totalCreditPoints / totalCredits).toFixed(2) : '8.65';
  const totalObtained = markItems.reduce((acc, item) => acc + item.marksObtained, 0);
  const totalMax = markItems.reduce((acc, item) => acc + item.maxMarks, 0);
  const percentage = totalMax > 0 ? ((totalObtained / totalMax) * 100).toFixed(1) : '86.5';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" />
            <h3 className="font-semibold text-slate-800 text-sm">Official Academic Transcript & Mark Sheet</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Transcript Document */}
        <div className="p-8 bg-slate-50/50">
          <div
            id="printable-transcript"
            className="bg-white p-8 rounded-xl border-2 border-slate-300 shadow-sm relative overflow-hidden"
          >
            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
              <GraduationCap className="w-96 h-96 text-slate-900" />
            </div>

            {/* University Header */}
            <div className="text-center pb-6 border-b-2 border-slate-900">
              <div className="flex items-center justify-center gap-2 mb-1">
                <GraduationCap className="w-7 h-7 text-indigo-700" />
                <h1 className="text-xl font-black tracking-wider uppercase text-slate-900">
                  Apex Institute of Technology
                </h1>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                Accredited Grade A+ by NAAC • Approved by AICTE • University Campus, Tech City
              </p>
              <div className="inline-block mt-3 px-4 py-1 rounded bg-slate-900 text-white text-xs font-bold tracking-widest uppercase">
                Semester Grade Card & Academic Transcript
              </div>
            </div>

            {/* Student Metadata Table */}
            <div className="grid grid-cols-2 gap-4 my-6 text-xs bg-slate-50 p-4 rounded-lg border border-slate-200">
              <div>
                <p className="text-slate-500">Student Name:</p>
                <p className="font-bold text-slate-900 text-sm">{student.firstName} {student.lastName}</p>
              </div>
              <div>
                <p className="text-slate-500">Roll / Registration No:</p>
                <p className="font-bold text-slate-900 font-mono text-sm">{student.rollNo}</p>
              </div>
              <div>
                <p className="text-slate-500">Degree & Program:</p>
                <p className="font-semibold text-slate-800">{student.degree} - {student.department}</p>
              </div>
              <div>
                <p className="text-slate-500">Semester & Academic Year:</p>
                <p className="font-semibold text-slate-800">Semester {student.semester} • 2025-2026</p>
              </div>
            </div>

            {/* Courses & Marks Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200 rounded">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200">
                    <th className="py-2.5 px-3 font-bold">Code</th>
                    <th className="py-2.5 px-3 font-bold">Course Title</th>
                    <th className="py-2.5 px-3 font-bold text-center">Credits</th>
                    <th className="py-2.5 px-3 font-bold text-center">Max</th>
                    <th className="py-2.5 px-3 font-bold text-center">Obtained</th>
                    <th className="py-2.5 px-3 font-bold text-center">Grade</th>
                    <th className="py-2.5 px-3 font-bold text-center">Grade Pt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {markItems.length > 0 ? (
                    markItems.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 font-mono font-medium text-slate-700">{item.courseCode}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-900">{item.courseName}</td>
                        <td className="py-2.5 px-3 text-center text-slate-700">{item.credits}</td>
                        <td className="py-2.5 px-3 text-center text-slate-500">{item.maxMarks}</td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">{item.marksObtained}</td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded font-bold ${
                            item.grade.startsWith('A')
                              ? 'bg-emerald-100 text-emerald-800'
                              : item.grade.startsWith('B')
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {item.grade}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-center font-semibold text-slate-700">{item.gradePoint}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="py-4 text-center text-slate-400">
                        No examination records uploaded for this semester yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Performance Summary Footnotes */}
            <div className="mt-6 flex flex-wrap items-center justify-between p-4 bg-slate-900 text-white rounded-lg">
              <div>
                <p className="text-[11px] text-slate-400">Total Marks Scored</p>
                <p className="text-base font-bold">{totalObtained} / {totalMax} ({percentage}%)</p>
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Semester GPA (SGPA)</p>
                <p className="text-lg font-black text-amber-400">{sgpa} / 10.0</p>
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Academic Status</p>
                <div className="flex items-center gap-1 text-emerald-400 font-bold text-xs">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>PASS WITH DISTINCTION</span>
                </div>
              </div>
            </div>

            {/* Signatures & Seal */}
            <div className="mt-12 pt-8 flex justify-between items-end text-center text-xs text-slate-600">
              <div>
                <div className="w-36 border-b border-slate-400 pb-1 font-mono text-[10px] text-slate-400">
                  SYSTEM VERIFIED
                </div>
                <p className="mt-1 font-semibold text-slate-800">Faculty Advisor</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-indigo-300 flex items-center justify-center text-[9px] text-indigo-400 uppercase font-bold text-center leading-tight">
                  Official Seal
                </div>
              </div>
              <div>
                <div className="w-36 border-b border-slate-400 pb-1 font-mono text-[10px] text-slate-400">
                  DIGITALLY SIGNED
                </div>
                <p className="mt-1 font-semibold text-slate-800">Controller of Examinations</p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">Security Verification Hash: 9f8a2-c10e-84b</span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded-lg transition"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Mark Sheet
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
