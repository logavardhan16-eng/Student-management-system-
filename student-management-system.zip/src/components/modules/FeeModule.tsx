import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import { FeeRecord, Student } from '../../types';
import { FeeReceiptModal } from '../common/FeeReceiptModal';
import {
  CreditCard,
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertCircle,
  Printer,
  Receipt,
  Plus,
  ArrowDownToLine,
  TrendingUp,
  X
} from 'lucide-react';

export const FeeModule: React.FC = () => {
  const { fees, students, recordFeePayment, addFeeInvoice, role } = useSMS();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [selectedReceipt, setSelectedReceipt] = useState<{ fee: FeeRecord; student: Student } | null>(null);
  const [collectingFee, setCollectingFee] = useState<FeeRecord | null>(null);

  // Collect Fee form state
  const [paymentAmount, setPaymentAmount] = useState<number>(10000);
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Online Banking' | 'Cash' | 'Card' | 'Cheque'>('UPI');

  // KPI calculations
  const totalInvoiced = fees.reduce((acc, f) => acc + f.totalAmount, 0);
  const totalCollected = fees.reduce((acc, f) => acc + f.paidAmount, 0);
  const totalPending = totalInvoiced - totalCollected;

  const handleOpenCollect = (fee: FeeRecord) => {
    setCollectingFee(fee);
    setPaymentAmount(fee.totalAmount - fee.paidAmount);
  };

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectingFee || paymentAmount <= 0) return;
    recordFeePayment(collectingFee.id, paymentAmount, paymentMethod);
    setCollectingFee(null);
  };

  const filteredFees = fees.filter((f) => {
    const stu = students.find((s) => s.id === f.studentId);
    const stuName = stu ? `${stu.firstName} ${stu.lastName}` : '';
    const matchesSearch =
      stuName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (stu?.rollNo.toLowerCase().includes(searchTerm.toLowerCase()) ?? false) ||
      f.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filterStatus === 'All' || f.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Fee Collection & Accounts Ledger</h2>
            <span className="bg-amber-50 text-amber-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-amber-100">
              Module 8
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Tuition fee structures, payment status, receipts generation, and outstanding dues reconciliation.
          </p>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Invoiced Dues</span>
          <p className="text-2xl font-black text-slate-900 mt-2">₹{totalInvoiced.toLocaleString()}</p>
          <p className="text-[11px] text-slate-400 mt-1">Odd Semester Academic Session</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">Total Fees Cleared</span>
          <p className="text-2xl font-black text-emerald-600 mt-2">₹{totalCollected.toLocaleString()}</p>
          <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
            <span className="font-semibold text-emerald-700">
              {totalInvoiced > 0 ? Math.round((totalCollected / totalInvoiced) * 100) : 0}%
            </span>
            <span>realization rate</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-red-500 uppercase tracking-wider">Outstanding Dues</span>
          <p className="text-2xl font-black text-red-600 mt-2">₹{totalPending.toLocaleString()}</p>
          <p className="text-[11px] text-slate-400 mt-1">Pending student clearance</p>
        </div>
      </div>

      {/* Search & Status Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="sm:col-span-8 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by student name, roll number, or invoice ID..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-amber-500 bg-slate-50/50"
          />
        </div>

        <div className="sm:col-span-4">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-amber-500 bg-slate-50/50 text-slate-700 font-medium"
          >
            <option value="All">All Payment Statuses</option>
            <option value="Paid">Paid in Full</option>
            <option value="Partial">Partial Payment</option>
            <option value="Pending">Pending</option>
            <option value="Overdue">Overdue Dues</option>
          </select>
        </div>
      </div>

      {/* Fees Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px] bg-slate-50/80">
                <th className="py-3 px-4">Invoice #</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Semester & Session</th>
                <th className="py-3 px-4 text-right">Total Payable</th>
                <th className="py-3 px-4 text-right">Cleared Amount</th>
                <th className="py-3 px-4 text-right">Balance Due</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Receipt & Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredFees.map((fee) => {
                const stu = students.find((s) => s.id === fee.studentId);
                const balance = fee.totalAmount - fee.paidAmount;

                return (
                  <tr key={fee.id} className="hover:bg-slate-50/60 transition">
                    <td className="py-3 px-4 font-mono font-bold text-slate-700">{fee.id}</td>

                    <td className="py-3 px-4">
                      {stu ? (
                        <div>
                          <p className="font-bold text-slate-900">{stu.firstName} {stu.lastName}</p>
                          <span className="text-[10px] text-slate-400 font-mono">{stu.rollNo}</span>
                        </div>
                      ) : (
                        <span className="text-slate-400">{fee.studentId}</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-slate-600">
                      <span>Sem {fee.semester} • {fee.academicYear}</span>
                    </td>

                    <td className="py-3 px-4 text-right font-semibold text-slate-800">
                      ₹{fee.totalAmount.toLocaleString()}
                    </td>

                    <td className="py-3 px-4 text-right font-bold text-emerald-600">
                      ₹{fee.paidAmount.toLocaleString()}
                    </td>

                    <td className="py-3 px-4 text-right font-bold text-red-600">
                      ₹{balance.toLocaleString()}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          fee.status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : fee.status === 'Partial'
                            ? 'bg-blue-100 text-blue-800'
                            : fee.status === 'Overdue'
                            ? 'bg-red-100 text-red-800 animate-pulse'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {fee.status}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Collect Fee button */}
                        {balance > 0 && role !== 'student' && (
                          <button
                            onClick={() => handleOpenCollect(fee)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] transition shadow-xs"
                          >
                            Collect
                          </button>
                        )}

                        {/* Print Receipt */}
                        {fee.paidAmount > 0 && stu && (
                          <button
                            onClick={() => setSelectedReceipt({ fee, student: stu })}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-[11px] transition"
                            title="Generate Official Payment Receipt"
                          >
                            <Printer className="w-3 h-3" />
                            <span>Receipt</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Collect Fee Modal */}
      {collectingFee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-800 text-sm">Collect Student Fee</h3>
              </div>
              <button
                onClick={() => setCollectingFee(null)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmPayment} className="p-6 space-y-4 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <p className="text-slate-500">Invoice Reference:</p>
                <p className="font-mono font-bold text-slate-800">{collectingFee.id}</p>
                <p className="text-slate-500 mt-1">Outstanding Due:</p>
                <p className="text-lg font-black text-red-600">
                  ₹{(collectingFee.totalAmount - collectingFee.paidAmount).toLocaleString()}
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Amount Receiving (₹) *</label>
                <input
                  type="number"
                  min={100}
                  max={collectingFee.totalAmount - collectingFee.paidAmount}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-bold border rounded-lg border-slate-300 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                >
                  <option value="UPI">UPI (Google Pay / PhonePe / BHIM)</option>
                  <option value="Online Banking">Net Banking / NEFT / RTGS</option>
                  <option value="Cash">Cash at University Cashier Desk</option>
                  <option value="Card">Debit / Credit Card POS</option>
                  <option value="Cheque">Demand Draft / Cheque</option>
                </select>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCollectingFee(null)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-sm"
                >
                  Confirm & Issue Receipt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Printable Fee Receipt Modal */}
      {selectedReceipt && (
        <FeeReceiptModal
          feeRecord={selectedReceipt.fee}
          student={selectedReceipt.student}
          onClose={() => setSelectedReceipt(null)}
        />
      )}
    </div>
  );
};
