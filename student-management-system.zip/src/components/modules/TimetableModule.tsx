import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import { TimetableSlot } from '../../types';
import {
  Clock,
  Plus,
  Calendar,
  MapPin,
  GraduationCap,
  Trash2,
  X,
  Filter
} from 'lucide-react';

export const TimetableModule: React.FC = () => {
  const {
    timetable,
    addTimetableSlot,
    deleteTimetableSlot,
    courses,
    teachers,
    role
  } = useSMS();

  const days: TimetableSlot['day'][] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const timeSlots = [
    '09:00 - 10:00 AM',
    '10:00 - 11:00 AM',
    '11:00 - 12:00 PM',
    '12:00 - 01:00 PM',
    '01:00 - 02:00 PM',
    '02:00 - 03:00 PM',
    '03:00 - 04:00 PM'
  ];

  const [selectedSemester, setSelectedSemester] = useState<number>(5);
  const [selectedTeacherFilter, setSelectedTeacherFilter] = useState<string>('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New slot form
  const [slotForm, setSlotForm] = useState<Omit<TimetableSlot, 'id' | 'courseName' | 'teacherName' | 'department'>>({
    day: 'Monday',
    timeSlot: '09:00 - 10:00 AM',
    courseId: courses[0]?.id || 'CS301',
    teacherId: teachers[0]?.id || 'FAC-101',
    room: 'LH-101',
    semester: 5
  });

  const handleCreateSlot = (e: React.FormEvent) => {
    e.preventDefault();
    const course = courses.find((c) => c.id === slotForm.courseId);
    const teacher = teachers.find((t) => t.id === slotForm.teacherId);

    addTimetableSlot({
      ...slotForm,
      courseName: course?.name || 'Curriculum Course',
      teacherName: teacher?.name || 'Faculty Member',
      department: course?.department || 'Engineering'
    });
    setIsAddModalOpen(false);
  };

  const filteredSlots = timetable.filter((slot) => {
    const matchSem = slot.semester === selectedSemester;
    const matchTeacher = selectedTeacherFilter === 'All' || slot.teacherId === selectedTeacherFilter;
    return matchSem && matchTeacher;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Academic Timetable & Schedule</h2>
            <span className="bg-teal-50 text-teal-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-teal-100">
              Module 9
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Weekly matrix of lectures, practical labs, and faculty classroom assignments.
          </p>
        </div>

        {role !== 'student' && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-sm shadow-teal-200 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Add Lecture Slot</span>
          </button>
        )}
      </div>

      {/* Filter Row */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap gap-4 items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-slate-600">Select Semester:</span>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
              <button
                key={sem}
                onClick={() => setSelectedSemester(sem)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  selectedSemester === sem
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Sem {sem}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-600">Faculty Filter:</span>
          <select
            value={selectedTeacherFilter}
            onChange={(e) => setSelectedTeacherFilter(e.target.value)}
            className="py-1.5 px-3 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-700"
          >
            <option value="All">All Faculty Members</option>
            {teachers.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Timetable Grid View */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
            Semester {selectedSemester} Schedule Grid • Monday through Saturday
          </h3>
          <span className="text-xs text-slate-500 font-medium">{filteredSlots.length} Active Slots</span>
        </div>

        <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {days.map((day) => {
            const daySlots = filteredSlots.filter((s) => s.day === day);

            return (
              <div key={day} className="bg-slate-50/70 rounded-xl p-4 border border-slate-200/80">
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-200">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-teal-600" />
                    <span>{day}</span>
                  </h4>
                  <span className="text-[10px] font-bold bg-white px-2 py-0.5 rounded-full text-slate-500 border border-slate-200">
                    {daySlots.length} Classes
                  </span>
                </div>

                <div className="space-y-2.5">
                  {daySlots.length > 0 ? (
                    daySlots.map((slot) => (
                      <div
                        key={slot.id}
                        className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs hover:border-teal-300 transition group"
                      >
                        <div className="flex items-start justify-between">
                          <span className="text-[11px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded">
                            {slot.timeSlot}
                          </span>
                          {role === 'admin' && (
                            <button
                              onClick={() => deleteTimetableSlot(slot.id)}
                              className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition"
                              title="Delete Slot"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <h5 className="font-bold text-slate-900 text-xs mt-2">{slot.courseName}</h5>
                        <p className="text-[10px] font-mono text-slate-400">{slot.courseId}</p>

                        <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
                          <span className="flex items-center gap-1 truncate max-w-[140px]">
                            <GraduationCap className="w-3 h-3 text-purple-600" />
                            <span className="truncate">{slot.teacherName}</span>
                          </span>
                          <span className="flex items-center gap-1 font-bold text-slate-800">
                            <MapPin className="w-3 h-3 text-red-500" />
                            <span>{slot.room}</span>
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="py-6 text-center text-slate-400 text-xs">
                      No lectures scheduled for {day}.
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Slot Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-teal-600" />
                <h3 className="font-bold text-slate-800 text-sm">Schedule Lecture Slot</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSlot} className="p-6 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Day of Week</label>
                  <select
                    value={slotForm.day}
                    onChange={(e) => setSlotForm({ ...slotForm, day: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                  >
                    {days.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Time Slot</label>
                  <select
                    value={slotForm.timeSlot}
                    onChange={(e) => setSlotForm({ ...slotForm, timeSlot: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                  >
                    {timeSlots.map((ts) => (
                      <option key={ts} value={ts}>
                        {ts}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject Course</label>
                <select
                  value={slotForm.courseId}
                  onChange={(e) => {
                    const c = courses.find((crs) => crs.id === e.target.value);
                    setSlotForm({
                      ...slotForm,
                      courseId: e.target.value,
                      semester: c?.semester || 5
                    });
                  }}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code}: {c.name} (Sem {c.semester})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Assigned Teacher</label>
                <select
                  value={slotForm.teacherId}
                  onChange={(e) => setSlotForm({ ...slotForm, teacherId: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                >
                  {teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.department})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Classroom / Hall</label>
                  <input
                    type="text"
                    required
                    value={slotForm.room}
                    onChange={(e) => setSlotForm({ ...slotForm, room: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                    placeholder="LH-101"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Semester</label>
                  <input
                    type="number"
                    readOnly
                    value={slotForm.semester}
                    className="w-full px-3 py-2 border rounded-lg border-slate-200 bg-slate-50 text-slate-600"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg shadow-sm"
                >
                  Add Slot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
