import React from 'react';
import { useSMS } from '../../context/SMSContext';
import {
  Users,
  GraduationCap,
  BookOpen,
  CreditCard,
  CalendarCheck,
  Award,
  AlertTriangle,
  TrendingUp,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  Plus
} from 'lucide-react';

export const DashboardModule: React.FC = () => {
  const {
    students,
    teachers,
    courses,
    fees,
    attendance,
    exams,
    notifications,
    setActiveTab,
    role,
    currentUserId
  } = useSMS();

  // Metrics Calculations
  const totalStudents = students.length;
  const totalTeachers = teachers.length;
  const totalCourses = courses.length;

  const totalFeeDemanded = fees.reduce((acc, f) => acc + f.totalAmount, 0);
  const totalFeeCollected = fees.reduce((acc, f) => acc + f.paidAmount, 0);
  const feeCollectionRate = totalFeeDemanded > 0 ? Math.round((totalFeeCollected / totalFeeDemanded) * 100) : 0;

  // Calculate overall attendance rate
  let totalPresentCount = 0;
  let totalRecordEntries = 0;
  attendance.forEach((att) => {
    att.records.forEach((r) => {
      totalRecordEntries++;
      if (r.status === 'Present') totalPresentCount++;
      else if (r.status === 'Late') totalPresentCount += 0.8;
    });
  });
  const overallAttendanceRate = totalRecordEntries > 0 ? Math.round((totalPresentCount / totalRecordEntries) * 100) : 88;

  // Pending fee students
  const defaulters = fees.filter((f) => f.status === 'Overdue' || f.status === 'Pending');

  // If role is Student, show personalized student view
  const myStudent = students.find((s) => s.id === currentUserId) || students[0];
  const myFee = fees.find((f) => f.studentId === myStudent?.id);

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-400 text-slate-900">
              Session 2025-2026
            </span>
            <span className="text-xs text-indigo-200">Odd Semester Active</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white">
            {role === 'student' && myStudent
              ? `Welcome back, ${myStudent.firstName}!`
              : role === 'teacher'
              ? 'Faculty Academic Control Hub'
              : 'Institutional Administrative Dashboard'}
          </h2>
          <p className="text-xs sm:text-sm text-indigo-100/90 mt-1">
            {role === 'student' && myStudent
              ? `${myStudent.degree} in ${myStudent.department} • Roll No: ${myStudent.rollNo} • Semester ${myStudent.semester}`
              : 'Real-time overview of student registration, course allocations, attendance monitoring, examination records, and fee ledgers.'}
          </p>

          {/* Quick Action Pills */}
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              onClick={() => setActiveTab('students')}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium backdrop-blur-xs transition"
            >
              <Users className="w-3.5 h-3.5 text-amber-300" />
              <span>Student Directory</span>
            </button>
            <button
              onClick={() => setActiveTab('attendance')}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium backdrop-blur-xs transition"
            >
              <CalendarCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>Attendance Sheet</span>
            </button>
            <button
              onClick={() => setActiveTab('exams')}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium backdrop-blur-xs transition"
            >
              <Award className="w-3.5 h-3.5 text-sky-300" />
              <span>Examinations & Marks</span>
            </button>
            <button
              onClick={() => setActiveTab('database')}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-400 text-slate-900 hover:bg-amber-300 text-xs font-bold transition shadow-xs"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Tech Stack & DB Tables</span>
            </button>
          </div>
        </div>

        {/* Decorative graphic element */}
        <div className="absolute right-0 top-0 bottom-0 w-80 opacity-10 flex items-center justify-center pointer-events-none">
          <GraduationCap className="w-80 h-80 text-white transform rotate-12 translate-x-12" />
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Students */}
        <div
          onClick={() => setActiveTab('students')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Registered Students</span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600 group-hover:scale-105 transition">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{totalStudents}</span>
            <span className="text-xs text-emerald-600 font-semibold flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> 100% Enrolled
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Across 4 Engineering Programs</p>
        </div>

        {/* Card 2: Faculty Members */}
        <div
          onClick={() => setActiveTab('teachers')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Faculty & Teachers</span>
            <div className="p-2 rounded-xl bg-purple-50 text-purple-600 group-hover:scale-105 transition">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{totalTeachers}</span>
            <span className="text-xs text-slate-500">Professors & Mentors</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">1:8 Faculty to Student Ratio</p>
        </div>

        {/* Card 3: Attendance Average */}
        <div
          onClick={() => setActiveTab('attendance')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Average Attendance</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600 group-hover:scale-105 transition">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{overallAttendanceRate}%</span>
            <span className="text-xs text-emerald-600 font-semibold">Healthy Range</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Threshold strictly monitored at 75%</p>
        </div>

        {/* Card 4: Fee Collection */}
        <div
          onClick={() => setActiveTab('fees')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Fee Collection</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600 group-hover:scale-105 transition">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">₹{(totalFeeCollected / 1000).toFixed(0)}k</span>
            <span className="text-xs text-slate-500">of ₹{(totalFeeDemanded / 1000).toFixed(0)}k</span>
          </div>
          <div className="mt-2 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all"
              style={{ width: `${feeCollectionRate}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Row: Academic Overview & Urgent Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active Courses & Examination Schedule */}
        <div className="lg:col-span-2 space-y-6">
          {/* Courses Snapshot */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Active Curriculum & Courses</h3>
                <p className="text-xs text-slate-500">Core engineering subjects for current semester</p>
              </div>
              <button
                onClick={() => setActiveTab('courses')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <span>View All ({courses.length})</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {courses.slice(0, 4).map((c) => (
                <div
                  key={c.id}
                  className="p-3.5 rounded-xl border border-slate-200/80 hover:border-indigo-200 hover:bg-indigo-50/20 transition group"
                >
                  <div className="flex items-start justify-between">
                    <span className="font-mono text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                      {c.code}
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium">{c.credits} Credits</span>
                  </div>
                  <h4 className="font-semibold text-slate-900 text-xs mt-2 group-hover:text-indigo-700 transition">
                    {c.name}
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-1">Instructor: {c.instructorName || 'Department Faculty'}</p>
                  <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                    <span>Room {c.room}</span>
                    <span>{c.enrolledCount} Students Enrolled</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Examination & Upcoming Schedules */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" />
                <h3 className="font-bold text-slate-900 text-sm">Scheduled Examinations</h3>
              </div>
              <button
                onClick={() => setActiveTab('exams')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <span>Manage Exams</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 divide-y divide-slate-100">
              {exams.map((exam) => (
                <div key={exam.id} className="py-3 flex items-center justify-between first:pt-0 last:pb-0">
                  <div>
                    <span className="text-xs font-semibold text-slate-800">{exam.name}</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">{exam.courseName} • Sem {exam.semester}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-indigo-600 bg-slate-100 px-2.5 py-1 rounded-md">
                      {exam.examDate}
                    </span>
                    <p className="text-[10px] text-slate-400 mt-1">Max: {exam.maxMarks} marks (Pass: {exam.passMarks})</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Important Notices & Fee Reminders */}
        <div className="space-y-6">
          {/* Institutional Notices */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">Notice Board</h3>
              <button
                onClick={() => setActiveTab('notifications')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                View All
              </button>
            </div>

            <div className="mt-3 space-y-3">
              {notifications.slice(0, 3).map((n) => (
                <div key={n.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      n.category === 'Exam'
                        ? 'bg-purple-100 text-purple-700'
                        : n.category === 'Fee'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-indigo-100 text-indigo-700'
                    }`}>
                      {n.category}
                    </span>
                    <span className="text-[10px] text-slate-400">{n.date}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 mt-1.5">{n.title}</h4>
                  <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">{n.content}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Fee Defaulters / Reminders Warning */}
          <div className="bg-amber-50/60 rounded-2xl border border-amber-200/80 p-5 shadow-xs">
            <div className="flex items-center gap-2 text-amber-900 mb-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h4 className="font-bold text-xs uppercase tracking-wider">Fee Collection Follow-up</h4>
            </div>
            <p className="text-xs text-amber-800">
              {defaulters.length} student(s) have pending or overdue fee installments for the current academic session.
            </p>
            <div className="mt-3 space-y-1.5">
              {defaulters.slice(0, 2).map((d) => {
                const stu = students.find((s) => s.id === d.studentId);
                return (
                  <div key={d.id} className="flex items-center justify-between bg-white/80 p-2 rounded-lg text-xs">
                    <span className="font-medium text-slate-800 truncate max-w-[140px]">
                      {stu ? `${stu.firstName} ${stu.lastName}` : d.studentId}
                    </span>
                    <span className="font-bold text-red-600">
                      ₹{(d.totalAmount - d.paidAmount).toLocaleString()} Due
                    </span>
                  </div>
                );
              })}
            </div>
            <button
              onClick={() => setActiveTab('fees')}
              className="mt-3 w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition shadow-xs"
            >
              Open Fee Manager
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
