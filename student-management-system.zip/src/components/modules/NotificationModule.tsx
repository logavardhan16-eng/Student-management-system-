import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import { Notification } from '../../types';
import {
  Bell,
  Plus,
  Trash2,
  Filter,
  Sparkles,
  Calendar,
  AlertCircle,
  Megaphone,
  X,
  UserCheck
} from 'lucide-react';

export const NotificationModule: React.FC = () => {
  const { notifications, addNotification, deleteNotification, role } = useSMS();

  const [categoryFilter, setCategoryFilter] = useState('All');
  const [isAddOpen, setIsAddOpen] = useState(false);

  const [notifForm, setNotifForm] = useState<Omit<Notification, 'id' | 'date'>>({
    title: '',
    content: '',
    category: 'General',
    targetAudience: 'All',
    isImportant: false,
    author: 'Dean of Student Affairs'
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifForm.title || !notifForm.content) return;
    addNotification(notifForm);
    setIsAddOpen(false);
    setNotifForm({
      title: '',
      content: '',
      category: 'General',
      targetAudience: 'All',
      isImportant: false,
      author: 'Office of the Dean'
    });
  };

  const filteredNotifs = notifications.filter((n) => {
    if (categoryFilter === 'All') return true;
    return n.category === categoryFilter;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Campus Announcements & Notices</h2>
            <span className="bg-amber-50 text-amber-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-amber-100">
              Module 11
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Broadcast examination alerts, fee deadlines, holiday notices, and institutional advisories.
          </p>
        </div>

        {role !== 'student' && (
          <button
            onClick={() => setIsAddOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>Publish Announcement</span>
          </button>
        )}
      </div>

      {/* Categories Filter Strip */}
      <div className="flex flex-wrap gap-2">
        {['All', 'Exam', 'Fee', 'Academic', 'Holiday', 'General'].map((cat) => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              categoryFilter === cat
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Notices Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredNotifs.map((item) => (
          <div
            key={item.id}
            className={`bg-white rounded-2xl p-5 border shadow-xs flex flex-col justify-between transition hover:shadow-md ${
              item.isImportant ? 'border-amber-300 ring-1 ring-amber-200/50' : 'border-slate-200'
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold ${
                      item.category === 'Exam'
                        ? 'bg-purple-100 text-purple-700'
                        : item.category === 'Fee'
                        ? 'bg-red-100 text-red-700'
                        : item.category === 'Academic'
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {item.category}
                  </span>
                  <span className="text-[10px] text-slate-500 bg-slate-50 px-2 py-0.5 rounded font-medium border border-slate-100">
                    Audience: {item.targetAudience}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-400 font-mono">{item.date}</span>
                  {role === 'admin' && (
                    <button
                      onClick={() => deleteNotification(item.id)}
                      className="text-slate-300 hover:text-red-500 transition p-1"
                      title="Remove Announcement"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <h3 className="font-bold text-slate-900 text-sm mt-3 flex items-start gap-1.5">
                {item.isImportant && <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />}
                <span>{item.title}</span>
              </h3>

              <p className="text-xs text-slate-600 mt-2 leading-relaxed whitespace-pre-line bg-slate-50 p-3 rounded-xl border border-slate-100">
                {item.content}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Published by: <strong className="text-slate-700">{item.author}</strong></span>
              <span className="font-mono text-[10px]">{item.id}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Notice Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-slate-800 text-sm">Create New Announcement</h3>
              </div>
              <button
                onClick={() => setIsAddOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Notice Title *</label>
                <input
                  type="text"
                  required
                  value={notifForm.title}
                  onChange={(e) => setNotifForm({ ...notifForm, title: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  placeholder="e.g. Schedule for University Lab Exams"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Notice Category</label>
                  <select
                    value={notifForm.category}
                    onChange={(e) => setNotifForm({ ...notifForm, category: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                  >
                    <option value="General">General</option>
                    <option value="Exam">Exam</option>
                    <option value="Fee">Fee</option>
                    <option value="Academic">Academic</option>
                    <option value="Holiday">Holiday</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Audience</label>
                  <select
                    value={notifForm.targetAudience}
                    onChange={(e) => setNotifForm({ ...notifForm, targetAudience: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                  >
                    <option value="All">All Campus Users</option>
                    <option value="Students">Students Only</option>
                    <option value="Teachers">Faculty / Staff Only</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Announcement Body / Content *</label>
                <textarea
                  rows={4}
                  required
                  value={notifForm.content}
                  onChange={(e) => setNotifForm({ ...notifForm, content: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  placeholder="Provide complete circular text, instructions, and dates..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3 items-center">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Author Authority</label>
                  <input
                    type="text"
                    value={notifForm.author}
                    onChange={(e) => setNotifForm({ ...notifForm, author: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
                <div className="pt-4 flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="importantCheck"
                    checked={notifForm.isImportant}
                    onChange={(e) => setNotifForm({ ...notifForm, isImportant: e.target.checked })}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                  />
                  <label htmlFor="importantCheck" className="font-semibold text-slate-700">
                    Pin as High Priority / Urgent
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg shadow-sm"
                >
                  Broadcast Notice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
