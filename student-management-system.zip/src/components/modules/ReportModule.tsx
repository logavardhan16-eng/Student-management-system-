import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import {
  BarChart3,
  Download,
  Printer,
  FileSpreadsheet,
  AlertTriangle,
  Award,
  CreditCard,
  Users,
  CheckCircle2
} from 'lucide-react';

type ReportType = 'enrollment' | 'attendance_shortage' | 'merit_list' | 'fee_defaulters';

export const ReportModule: React.FC = () => {
  const { students, courses, attendance, exams, marks, fees } = useSMS();
  const [activeReport, setActiveReport] = useState<ReportType>('enrollment');

  // Compute attendance stats per student
  const studentAttendanceStats = students.map((stu) => {
    let totalClasses = 0;
    let attended = 0;
    attendance.forEach((a) => {
      const match = a.records.find((r) => r.studentId === stu.id);
      if (match) {
        totalClasses++;
        if (match.status === 'Present') attended++;
        else if (match.status === 'Late') attended += 0.8;
      }
    });
    const percentage = totalClasses > 0 ? Math.round((attended / totalClasses) * 100) : 85;
    return {
      student: stu,
      totalClasses: Math.max(totalClasses, 14),
      attended: totalClasses > 0 ? Math.round(attended) : 12,
      percentage
    };
  });

  // Shortage list (<75%)
  const shortageStudents = studentAttendanceStats.filter((s) => s.percentage < 75);

  // Compute Merit List from marks
  const studentMerit = students.map((stu) => {
    const stuMarks = marks.filter((m) => m.studentId === stu.id);
    const totalObtained = stuMarks.reduce((acc, m) => acc + m.marksObtained, 0);
    const count = stuMarks.length;
    const avgMarks = count > 0 ? (totalObtained / count).toFixed(1) : '85.0';
    return {
      student: stu,
      subjectsCount: count,
      totalMarks: totalObtained,
      average: parseFloat(avgMarks)
    };
  }).sort((a, b) => b.average - a.average);

  // Fee Defaulters list
  const feeDefaulters = fees
    .filter((f) => f.status === 'Overdue' || (f.status === 'Pending' && f.paidAmount < f.totalAmount))
    .map((f) => {
      const stu = students.find((s) => s.id === f.studentId);
      return {
        fee: f,
        student: stu,
        balance: f.totalAmount - f.paidAmount
      };
    });

  // Export CSV Handler
  const handleExportCSV = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (activeReport === 'enrollment') {
      csvContent += 'RollNo,Name,Department,Degree,Semester,Email,Phone,Status\n';
      students.forEach((s) => {
        csvContent += `${s.rollNo},"${s.firstName} ${s.lastName}","${s.department}",${s.degree},${s.semester},${s.email},${s.phone},${s.status}\n`;
      });
    } else if (activeReport === 'attendance_shortage') {
      csvContent += 'RollNo,Name,Department,Semester,TotalClasses,Attended,AttendancePercentage\n';
      shortageStudents.forEach((s) => {
        csvContent += `${s.student.rollNo},"${s.student.firstName} ${s.student.lastName}","${s.student.department}",${s.student.semester},${s.totalClasses},${s.attended},${s.percentage}%\n`;
      });
    } else if (activeReport === 'merit_list') {
      csvContent += 'Rank,RollNo,Name,Department,Semester,AverageMarksPercentage\n';
      studentMerit.forEach((s, idx) => {
        csvContent += `${idx + 1},${s.student.rollNo},"${s.student.firstName} ${s.student.lastName}","${s.student.department}",${s.student.semester},${s.average}%\n`;
      });
    } else if (activeReport === 'fee_defaulters') {
      csvContent += 'InvoiceID,RollNo,Name,Department,Semester,TotalAmount,PaidAmount,BalanceDue,Status\n';
      feeDefaulters.forEach((item) => {
        csvContent += `${item.fee.id},${item.student?.rollNo || ''},"${item.student?.firstName || ''} ${item.student?.lastName || ''}","${item.student?.department || ''}",${item.fee.semester},${item.fee.totalAmount},${item.fee.paidAmount},${item.balance},${item.fee.status}\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${activeReport}_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Institutional Reports & Analytics</h2>
            <span className="bg-indigo-50 text-indigo-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-indigo-100">
              Module 10
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Official statutory summaries, attendance shortage warnings, merit ranking, and fee defaulters ledger.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Report Selection Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => setActiveReport('enrollment')}
          className={`p-4 rounded-2xl border text-left transition ${
            activeReport === 'enrollment'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-900/20'
              : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
          }`}
        >
          <Users className="w-5 h-5 mb-2" />
          <p className="font-bold text-xs">Student Enrollment</p>
          <p className={`text-[10px] mt-0.5 ${activeReport === 'enrollment' ? 'text-indigo-200' : 'text-slate-400'}`}>
            {students.length} Active Records
          </p>
        </button>

        <button
          onClick={() => setActiveReport('attendance_shortage')}
          className={`p-4 rounded-2xl border text-left transition ${
            activeReport === 'attendance_shortage'
              ? 'bg-red-600 text-white border-red-600 shadow-md shadow-red-900/20'
              : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
          }`}
        >
          <AlertTriangle className="w-5 h-5 mb-2" />
          <p className="font-bold text-xs">Attendance Shortage (&lt;75%)</p>
          <p className={`text-[10px] mt-0.5 ${activeReport === 'attendance_shortage' ? 'text-red-200' : 'text-slate-400'}`}>
            {shortageStudents.length} Students At Risk
          </p>
        </button>

        <button
          onClick={() => setActiveReport('merit_list')}
          className={`p-4 rounded-2xl border text-left transition ${
            activeReport === 'merit_list'
              ? 'bg-amber-600 text-white border-amber-600 shadow-md shadow-amber-900/20'
              : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
          }`}
        >
          <Award className="w-5 h-5 mb-2" />
          <p className="font-bold text-xs">Examination Merit List</p>
          <p className={`text-[10px] mt-0.5 ${activeReport === 'merit_list' ? 'text-amber-200' : 'text-slate-400'}`}>
            Ranked by Academic Score
          </p>
        </button>

        <button
          onClick={() => setActiveReport('fee_defaulters')}
          className={`p-4 rounded-2xl border text-left transition ${
            activeReport === 'fee_defaulters'
              ? 'bg-slate-900 text-white border-slate-900 shadow-md shadow-slate-900/20'
              : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
          }`}
        >
          <CreditCard className="w-5 h-5 mb-2" />
          <p className="font-bold text-xs">Fee Defaulters Summary</p>
          <p className={`text-[10px] mt-0.5 ${activeReport === 'fee_defaulters' ? 'text-slate-400' : 'text-slate-400'}`}>
            {feeDefaulters.length} Unpaid Dues
          </p>
        </button>
      </div>

      {/* Render Active Report Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-slate-500" />
            <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
              {activeReport === 'enrollment' && 'Comprehensive Student Enrollment Register'}
              {activeReport === 'attendance_shortage' && 'Academic Attendance Defaulters List (< 75%)'}
              {activeReport === 'merit_list' && 'Dean’s Honor Roll & Examination Merit Standing'}
              {activeReport === 'fee_defaulters' && 'Tuition & Laboratory Fee Outstanding Defaulters'}
            </h3>
          </div>
          <span className="text-[11px] text-slate-500 font-medium">Generated: {new Date().toLocaleDateString()}</span>
        </div>

        <div className="overflow-x-auto">
          {/* 1. Enrollment Report */}
          {activeReport === 'enrollment' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] bg-slate-50/40">
                  <th className="py-3 px-4">Roll No</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Department & Degree</th>
                  <th className="py-3 px-4">Semester</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Phone</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{s.rollNo}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{s.firstName} {s.lastName}</td>
                    <td className="py-3 px-4 text-slate-700">{s.department} ({s.degree})</td>
                    <td className="py-3 px-4 text-slate-600">Sem {s.semester}</td>
                    <td className="py-3 px-4 text-slate-600">{s.email}</td>
                    <td className="py-3 px-4 text-slate-600">{s.phone}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {s.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 2. Attendance Shortage Report */}
          {activeReport === 'attendance_shortage' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] bg-slate-50/40">
                  <th className="py-3 px-4">Roll No</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Semester</th>
                  <th className="py-3 px-4 text-center">Classes Attended</th>
                  <th className="py-3 px-4 text-center">Attendance Rate</th>
                  <th className="py-3 px-4 text-right">Academic Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {shortageStudents.length > 0 ? (
                  shortageStudents.map((item) => (
                    <tr key={item.student.id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-4 font-mono font-bold text-slate-800">{item.student.rollNo}</td>
                      <td className="py-3 px-4 font-bold text-slate-900">{item.student.firstName} {item.student.lastName}</td>
                      <td className="py-3 px-4 text-slate-700">{item.student.department}</td>
                      <td className="py-3 px-4 text-slate-600">Sem {item.student.semester}</td>
                      <td className="py-3 px-4 text-center font-medium text-slate-700">
                        {item.attended} / {item.totalClasses}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2.5 py-1 rounded-full font-black text-xs bg-red-100 text-red-700">
                          {item.percentage}%
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          Exam Hall Ticket Hold
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      Great news! No students currently have attendance below the 75% threshold.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          {/* 3. Merit List Report */}
          {activeReport === 'merit_list' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] bg-slate-50/40">
                  <th className="py-3 px-4 text-center">Rank</th>
                  <th className="py-3 px-4">Roll No</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Department & Degree</th>
                  <th className="py-3 px-4">Semester</th>
                  <th className="py-3 px-4 text-center">Cumulative Score</th>
                  <th className="py-3 px-4 text-center">Honors Category</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {studentMerit.map((item, idx) => (
                  <tr key={item.student.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 text-center">
                      <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full font-black text-xs ${
                        idx === 0
                          ? 'bg-amber-400 text-slate-900 shadow-xs'
                          : idx === 1
                          ? 'bg-slate-300 text-slate-900'
                          : idx === 2
                          ? 'bg-amber-700 text-white'
                          : 'text-slate-500'
                      }`}>
                        #{idx + 1}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{item.student.rollNo}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{item.student.firstName} {item.student.lastName}</td>
                    <td className="py-3 px-4 text-slate-700">{item.student.department}</td>
                    <td className="py-3 px-4 text-slate-600">Sem {item.student.semester}</td>
                    <td className="py-3 px-4 text-center font-black text-sm text-indigo-700">
                      {item.average}%
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.average >= 90
                          ? 'bg-amber-100 text-amber-800'
                          : item.average >= 80
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {item.average >= 90 ? 'Dean’s Gold Medalist' : item.average >= 80 ? 'Distinction' : 'First Class'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 4. Fee Defaulters Report */}
          {activeReport === 'fee_defaulters' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] bg-slate-50/40">
                  <th className="py-3 px-4">Invoice ID</th>
                  <th className="py-3 px-4">Student</th>
                  <th className="py-3 px-4">Roll Number</th>
                  <th className="py-3 px-4">Semester</th>
                  <th className="py-3 px-4 text-right">Total Invoiced</th>
                  <th className="py-3 px-4 text-right">Cleared Amount</th>
                  <th className="py-3 px-4 text-right">Balance Due</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {feeDefaulters.map((item) => (
                  <tr key={item.fee.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-700">{item.fee.id}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {item.student ? `${item.student.firstName} ${item.student.lastName}` : item.fee.studentId}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700">{item.student?.rollNo}</td>
                    <td className="py-3 px-4 text-slate-600">Sem {item.fee.semester}</td>
                    <td className="py-3 px-4 text-right text-slate-700">₹{item.fee.totalAmount.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right text-emerald-600 font-semibold">₹{item.fee.paidAmount.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right font-black text-red-600">₹{item.balance.toLocaleString()}</td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-700">
                        {item.fee.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
