import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import { Course } from '../../types';
import {
  BookOpen,
  Plus,
  Users,
  Clock,
  MapPin,
  Edit2,
  Trash2,
  X,
  Search,
  CheckCircle,
  GraduationCap
} from 'lucide-react';

export const CourseModule: React.FC = () => {
  const {
    courses,
    addCourse,
    updateCourse,
    deleteCourse,
    teachers,
    students,
    role
  } = useSMS();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSemester, setSelectedSemester] = useState('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [viewingRosterCourse, setViewingRosterCourse] = useState<Course | null>(null);

  const [formData, setFormData] = useState<Omit<Course, 'enrolledCount'>>({
    id: '',
    name: '',
    code: '',
    department: 'Computer Science & Engineering',
    semester: 5,
    credits: 4,
    instructorId: teachers[0]?.id || '',
    instructorName: teachers[0]?.name || '',
    capacity: 60,
    description: '',
    schedule: 'Mon, Wed (10:00 - 11:30 AM)',
    room: 'LH-101'
  });

  const handleOpenAdd = () => {
    setFormData({
      id: `CS${Math.floor(300 + Math.random() * 90)}`,
      name: '',
      code: `CS${Math.floor(300 + Math.random() * 90)}`,
      department: 'Computer Science & Engineering',
      semester: 5,
      credits: 4,
      instructorId: teachers[0]?.id || '',
      instructorName: teachers[0]?.name || '',
      capacity: 60,
      description: '',
      schedule: 'Mon, Wed, Fri (10:00 - 11:00 AM)',
      room: 'LH-201'
    });
    setIsAddModalOpen(true);
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.code) {
      alert('Please fill in Course Name and Code.');
      return;
    }
    const instructor = teachers.find((t) => t.id === formData.instructorId);
    addCourse({
      ...formData,
      id: formData.code,
      instructorName: instructor?.name || formData.instructorName,
      enrolledCount: Math.min(formData.capacity, students.filter((s) => s.semester === formData.semester).length)
    });
    setIsAddModalOpen(false);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCourse) return;
    const instructor = teachers.find((t) => t.id === editingCourse.instructorId);
    updateCourse(editingCourse.id, {
      ...editingCourse,
      instructorName: instructor?.name || editingCourse.instructorName
    });
    setEditingCourse(null);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete course ${name}?`)) {
      deleteCourse(id);
    }
  };

  const filteredCourses = courses.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSem = selectedSemester === 'All' || c.semester.toString() === selectedSemester;
    return matchesSearch && matchesSem;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Course & Curriculum Management</h2>
            <span className="bg-indigo-50 text-indigo-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-indigo-100">
              {courses.length} Active Courses
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Maintain course catalog, credit allocations, syllabus, room assignments, and student enrollment rosters.
          </p>
        </div>

        {role === 'admin' && (
          <button
            onClick={handleOpenAdd}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm shadow-indigo-200 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Course</span>
          </button>
        )}
      </div>

      {/* Search and Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="sm:col-span-8 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by course code, title, or department..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-indigo-500 bg-slate-50/50"
          />
        </div>
        <div className="sm:col-span-4">
          <select
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-indigo-500 bg-slate-50/50 text-slate-700 font-medium"
          >
            <option value="All">All Semesters</option>
            {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
              <option key={s} value={s.toString()}>
                Semester {s} Courses
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCourses.map((course) => (
          <div
            key={course.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-start justify-between">
                <span className="font-mono text-xs font-black text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-md border border-indigo-200/60">
                  {course.code}
                </span>
                <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full">
                  {course.credits} Credits
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm mt-3 group-hover:text-indigo-600 transition">
                {course.name}
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 font-medium">{course.department}</p>

              <p className="text-xs text-slate-600 mt-3 line-clamp-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                {course.description || 'Core engineering syllabus covering theoretical principles and laboratory experiments.'}
              </p>

              <div className="mt-4 space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                  <span className="truncate">Instructor: <strong className="text-slate-800">{course.instructorName}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span className="text-[11px]">{course.schedule}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0" />
                  <span className="text-[11px]">Classroom / Lab: <strong className="text-slate-800">{course.room}</strong></span>
                </div>
              </div>

              {/* Enrollment Bar */}
              <div className="mt-4 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between text-[11px] mb-1">
                  <span className="text-slate-500">Student Enrollment</span>
                  <span className="font-bold text-slate-800">
                    {course.enrolledCount} / {course.capacity}
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full"
                    style={{ width: `${Math.min(100, (course.enrolledCount / course.capacity) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => setViewingRosterCourse(course)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Class Roster</span>
              </button>

              {role === 'admin' && (
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setEditingCourse(course)}
                    title="Edit Course"
                    className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 transition"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(course.id, course.name)}
                    title="Delete Course"
                    className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Class Roster Modal */}
      {viewingRosterCourse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="font-bold text-slate-800 text-sm">
                    {viewingRosterCourse.code}: {viewingRosterCourse.name}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Semester {viewingRosterCourse.semester} • Instructor: {viewingRosterCourse.instructorName}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setViewingRosterCourse(null)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                Enrolled Students in this Course
              </h4>
              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto pr-1">
                {students
                  .filter((s) => s.semester === viewingRosterCourse.semester)
                  .map((stu) => (
                    <div key={stu.id} className="py-2.5 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-100">
                          <img
                            src={stu.avatarUrl}
                            alt={stu.firstName}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-900">
                            {stu.firstName} {stu.lastName}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">{stu.rollNo} • {stu.email}</p>
                        </div>
                      </div>
                      <span className="text-[10px] bg-emerald-50 text-emerald-700 font-semibold px-2 py-0.5 rounded-full border border-emerald-100">
                        Enrolled
                      </span>
                    </div>
                  ))}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
                <button
                  onClick={() => setViewingRosterCourse(null)}
                  className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold"
                >
                  Close Roster
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Course Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-800 text-sm">Add New Curriculum Course</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAdd} className="p-6 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Course Code *</label>
                  <input
                    type="text"
                    required
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300 font-mono"
                    placeholder="e.g. CS401"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Course Title *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                    placeholder="e.g. Operating Systems"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Credits</label>
                  <input
                    type="number"
                    min={1}
                    max={6}
                    value={formData.credits}
                    onChange={(e) => setFormData({ ...formData, credits: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Semester</label>
                  <select
                    value={formData.semester}
                    onChange={(e) => setFormData({ ...formData, semester: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                      <option key={s} value={s}>
                        Sem {s}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Capacity</label>
                  <input
                    type="number"
                    value={formData.capacity}
                    onChange={(e) => setFormData({ ...formData, capacity: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Lead Instructor</label>
                <select
                  value={formData.instructorId}
                  onChange={(e) => {
                    const inst = teachers.find((t) => t.id === e.target.value);
                    setFormData({
                      ...formData,
                      instructorId: e.target.value,
                      instructorName: inst?.name || ''
                    });
                  }}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                >
                  {teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.department})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Weekly Schedule</label>
                  <input
                    type="text"
                    value={formData.schedule}
                    onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                    placeholder="Mon, Wed, Fri (10:00 AM)"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Classroom / Lab</label>
                  <input
                    type="text"
                    value={formData.room}
                    onChange={(e) => setFormData({ ...formData, room: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                    placeholder="LH-101"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Syllabus Overview</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  placeholder="Core themes, prerequisite requirements, and lab modules."
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm"
                >
                  Save Course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Course Modal */}
      {editingCourse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-800 text-sm">Edit Course: {editingCourse.code}</h3>
              </div>
              <button
                onClick={() => setEditingCourse(null)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Course Title</label>
                <input
                  type="text"
                  required
                  value={editingCourse.name}
                  onChange={(e) => setEditingCourse({ ...editingCourse, name: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Credits</label>
                  <input
                    type="number"
                    value={editingCourse.credits}
                    onChange={(e) => setEditingCourse({ ...editingCourse, credits: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Classroom</label>
                  <input
                    type="text"
                    value={editingCourse.room}
                    onChange={(e) => setEditingCourse({ ...editingCourse, room: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Schedule</label>
                <input
                  type="text"
                  value={editingCourse.schedule}
                  onChange={(e) => setEditingCourse({ ...editingCourse, schedule: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingCourse(null)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-sm"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
