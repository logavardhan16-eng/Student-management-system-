import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import {
  Database,
  Download,
  Upload,
  RefreshCw,
  Server,
  Table,
  CheckCircle2,
  FileCode,
  HardDrive,
  Copy,
  Check
} from 'lucide-react';

export const DatabaseModule: React.FC = () => {
  const {
    students,
    teachers,
    courses,
    attendance,
    exams,
    marks,
    fees,
    timetable,
    notifications,
    resetDatabase,
    exportDatabaseJSON,
    importDatabaseJSON
  } = useSMS();

  const [copiedTable, setCopiedTable] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'schema' | 'export_sql'>('overview');
  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);

  // Stats
  const tableStats = [
    { name: 'students', rows: students.length, desc: 'Student enrollment profiles, roll numbers, credentials, and parent info' },
    { name: 'teachers', rows: teachers.length, desc: 'Faculty directory, qualifications, designation, and subject assignments' },
    { name: 'courses', rows: courses.length, desc: 'Curriculum catalog, course credits, capacity, and weekly hours' },
    { name: 'attendance', rows: attendance.length, desc: 'Daily attendance session records, present/absent logs' },
    { name: 'exams', rows: exams.length, desc: 'Mid-term and end-term exam assessments, max marks, and dates' },
    { name: 'marks', rows: marks.length, desc: 'Student grading, marks scored, calculated letter grades, and feedback' },
    { name: 'fees', rows: fees.length, desc: 'Semester fee ledger, paid amounts, payment modes, and invoice receipts' },
    { name: 'timetable', rows: timetable.length, desc: 'Weekly lecture timetable, classroom mappings, and period slots' },
    { name: 'notifications', rows: notifications.length, desc: 'Circulars, alerts, exam timetables, and college advisories' }
  ];

  const totalRecords = tableStats.reduce((acc, t) => acc + t.rows, 0);

  // Backup Full JSON
  const handleBackupJSON = () => {
    const fullBackup = {
      timestamp: new Date().toISOString(),
      system: 'Student Management System (SMS) v2.5',
      tables: {
        students,
        teachers,
        courses,
        attendance,
        exams,
        marks,
        fees,
        timetable,
        notifications
      }
    };

    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sms_database_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Generate MySQL / PostgreSQL DDL Script
  const generateSQLDump = () => {
    return `-- ==========================================================
-- Student Management System (SMS) - Relational SQL Schema & DDL
-- Generated: ${new Date().toISOString()}
-- Database Engine: MySQL / PostgreSQL Compatible
-- ==========================================================

CREATE TABLE IF NOT EXISTS students (
  id VARCHAR(20) PRIMARY KEY,
  roll_no VARCHAR(20) UNIQUE NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  phone VARCHAR(20) NOT NULL,
  department VARCHAR(100) NOT NULL,
  degree VARCHAR(50) NOT NULL,
  semester INT NOT NULL,
  dob DATE NOT NULL,
  gender VARCHAR(10) NOT NULL,
  blood_group VARCHAR(5),
  guardian_name VARCHAR(100) NOT NULL,
  guardian_phone VARCHAR(20) NOT NULL,
  status VARCHAR(20) DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS teachers (
  id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  phone VARCHAR(20) NOT NULL,
  department VARCHAR(100) NOT NULL,
  designation VARCHAR(50) NOT NULL,
  qualification VARCHAR(100) NOT NULL,
  experience_years INT NOT NULL,
  joining_date DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS courses (
  id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  code VARCHAR(20) UNIQUE NOT NULL,
  department VARCHAR(100) NOT NULL,
  semester INT NOT NULL,
  credits INT NOT NULL,
  instructor_id VARCHAR(20) REFERENCES teachers(id),
  capacity INT DEFAULT 60,
  schedule VARCHAR(100),
  room VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS attendance (
  id VARCHAR(30) PRIMARY KEY,
  course_id VARCHAR(20) REFERENCES courses(id),
  date DATE NOT NULL,
  student_id VARCHAR(20) REFERENCES students(id),
  status VARCHAR(15) CHECK (status IN ('Present', 'Absent', 'Late')),
  remarks TEXT
);

CREATE TABLE IF NOT EXISTS exams (
  id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  course_id VARCHAR(20) REFERENCES courses(id),
  semester INT NOT NULL,
  exam_date DATE NOT NULL,
  max_marks INT DEFAULT 100,
  pass_marks INT DEFAULT 40,
  weightage INT DEFAULT 50
);

CREATE TABLE IF NOT EXISTS marks (
  id VARCHAR(30) PRIMARY KEY,
  exam_id VARCHAR(20) REFERENCES exams(id),
  student_id VARCHAR(20) REFERENCES students(id),
  course_id VARCHAR(20) REFERENCES courses(id),
  marks_obtained NUMERIC(5,2) NOT NULL,
  grade VARCHAR(5) NOT NULL,
  feedback TEXT
);

CREATE TABLE IF NOT EXISTS fees (
  id VARCHAR(20) PRIMARY KEY,
  student_id VARCHAR(20) REFERENCES students(id),
  semester INT NOT NULL,
  academic_year VARCHAR(20) NOT NULL,
  total_amount NUMERIC(10,2) NOT NULL,
  paid_amount NUMERIC(10,2) DEFAULT 0,
  due_date DATE NOT NULL,
  status VARCHAR(20) CHECK (status IN ('Paid', 'Pending', 'Partial', 'Overdue')),
  payment_method VARCHAR(30)
);

CREATE TABLE IF NOT EXISTS timetable (
  id VARCHAR(30) PRIMARY KEY,
  day VARCHAR(15) NOT NULL,
  time_slot VARCHAR(30) NOT NULL,
  course_id VARCHAR(20) REFERENCES courses(id),
  teacher_id VARCHAR(20) REFERENCES teachers(id),
  room VARCHAR(30) NOT NULL,
  semester INT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id VARCHAR(20) PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  content TEXT NOT NULL,
  category VARCHAR(20) NOT NULL,
  target_audience VARCHAR(20) DEFAULT 'All',
  date DATE NOT NULL,
  is_important BOOLEAN DEFAULT FALSE,
  author VARCHAR(100)
);
`;
  };

  const handleCopySQL = () => {
    navigator.clipboard.writeText(generateSQLDump());
    setCopiedTable('sql');
    setTimeout(() => setCopiedTable(null), 2500);
  };

  const handleDownloadSQL = () => {
    const blob = new Blob([generateSQLDump()], { type: 'text/sql' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sms_database_schema.sql`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importDatabaseJSON(content);
      if (success) {
        setRestoreStatus('Database successfully restored from JSON backup! State updated.');
        setTimeout(() => setRestoreStatus(null), 3500);
      } else {
        alert('Failed to restore backup: Invalid JSON backup schema.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetConfirm = () => {
    if (window.confirm('Are you sure you want to reset all data back to the clean seed dataset? Any custom additions will be reverted.')) {
      resetDatabase();
      setRestoreStatus('All tables reset to clean initial seed data.');
      setTimeout(() => setRestoreStatus(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Database Administration & Storage</h2>
            <span className="bg-indigo-50 text-indigo-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-indigo-100">
              Module 12
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time entity persistence, SQL DDL schema definitions, automated JSON backups, and database resets.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleBackupJSON}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition"
          >
            <Download className="w-4 h-4" />
            <span>Backup JSON</span>
          </button>

          <label className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer transition">
            <Upload className="w-4 h-4" />
            <span>Restore JSON</span>
            <input type="file" accept=".json" onChange={handleRestoreFile} className="hidden" />
          </label>

          <button
            onClick={handleResetConfirm}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl text-xs font-bold transition border border-red-200"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Reset to Seed</span>
          </button>
        </div>
      </div>

      {restoreStatus && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{restoreStatus}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'overview' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Database Overview ({tableStats.length} Tables)
        </button>
        <button
          onClick={() => setActiveTab('export_sql')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'export_sql' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          SQL Schema & DDL Queries
        </button>
      </div>

      {/* Tab: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
                <Database className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Database Architecture</span>
                <p className="text-lg font-black text-slate-900">Relational + Storage</p>
                <span className="text-[10px] text-emerald-600 font-bold">● Active & Synchronized</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                <Table className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Total System Records</span>
                <p className="text-2xl font-black text-slate-900">{totalRecords}</p>
                <span className="text-[10px] text-slate-400">across 9 database tables</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                <HardDrive className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Persistence Medium</span>
                <p className="text-lg font-black text-slate-900">Browser Cache & JSON</p>
                <span className="text-[10px] text-slate-400">Zero data loss on page refresh</span>
              </div>
            </div>
          </div>

          {/* Tables Summary Matrix */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                Database Schema Tables Dictionary
              </h3>
              <span className="text-xs text-slate-500 font-medium">9 Primary Entities</span>
            </div>

            <div className="divide-y divide-slate-100">
              {tableStats.map((table) => (
                <div key={table.name} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-50/50">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-black text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded border border-indigo-200/60">
                      {table.name}
                    </span>
                    <p className="text-xs text-slate-600">{table.desc}</p>
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    <span className="font-bold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-full">
                      {table.rows} records
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: SQL Schema & DDL Queries */}
      {activeTab === 'export_sql' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
          <div className="px-5 py-4 bg-slate-950 flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2">
              <FileCode className="w-5 h-5 text-indigo-400" />
              <span className="text-xs font-mono font-bold text-slate-300">sms_schema.sql (PostgreSQL / MySQL DDL)</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopySQL}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium transition"
              >
                {copiedTable === 'sql' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedTable === 'sql' ? 'Copied!' : 'Copy SQL'}</span>
              </button>
              <button
                onClick={handleDownloadSQL}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .sql</span>
              </button>
            </div>
          </div>

          <div className="p-5 max-h-[500px] overflow-y-auto font-mono text-[11px] text-emerald-400/90 leading-relaxed">
            <pre className="whitespace-pre-wrap">{generateSQLDump()}</pre>
          </div>
        </div>
      )}
    </div>
  );
};
