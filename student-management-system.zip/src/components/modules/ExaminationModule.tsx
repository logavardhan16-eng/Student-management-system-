import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import { Exam, StudentMark, Student } from '../../types';
import { MarkSheetModal } from '../common/MarkSheetModal';
import {
  Award,
  Plus,
  Save,
  CheckCircle,
  Printer,
  Calendar,
  BookOpen,
  X,
  FileSpreadsheet
} from 'lucide-react';

export const ExaminationModule: React.FC = () => {
  const {
    exams,
    addExam,
    courses,
    students,
    marks,
    saveStudentMarks,
    role
  } = useSMS();

  const [selectedExamId, setSelectedExamId] = useState<string>(exams[0]?.id || 'EXAM-01');
  const [isAddExamOpen, setIsAddExamOpen] = useState(false);
  const [selectedStudentForSheet, setSelectedStudentForSheet] = useState<Student | null>(null);
  const [feedbackSuccess, setFeedbackSuccess] = useState<string | null>(null);

  const selectedExam = exams.find((e) => e.id === selectedExamId) || exams[0];
  const relevantCourse = courses.find((c) => c.id === selectedExam?.courseId);
  const eligibleStudents = students.filter((s) => s.semester === selectedExam?.semester);

  // Draft marks state for editing
  const [draftMarks, setDraftMarks] = useState<{
    [studentId: string]: { marksObtained: number; grade: StudentMark['grade']; feedback: string };
  }>({});

  // Initialize draft marks from existing saved marks
  React.useEffect(() => {
    const map: typeof draftMarks = {};
    eligibleStudents.forEach((stu) => {
      const existing = marks.find(
        (m) => m.examId === selectedExamId && m.studentId === stu.id
      );
      if (existing) {
        map[stu.id] = {
          marksObtained: existing.marksObtained,
          grade: existing.grade,
          feedback: existing.feedback || ''
        };
      } else {
        map[stu.id] = {
          marksObtained: 75,
          grade: 'B+',
          feedback: ''
        };
      }
    });
    setDraftMarks(map);
  }, [selectedExamId, eligibleStudents.length]);

  // Helper to compute grade from marks
  const computeGrade = (marks: number, max: number): StudentMark['grade'] => {
    const pct = (marks / max) * 100;
    if (pct >= 90) return 'A+';
    if (pct >= 80) return 'A';
    if (pct >= 70) return 'B+';
    if (pct >= 60) return 'B';
    if (pct >= 50) return 'C';
    if (pct >= 40) return 'D';
    return 'F';
  };

  const handleMarkChange = (studentId: string, val: number) => {
    const clamped = Math.max(0, Math.min(selectedExam ? selectedExam.maxMarks : 100, val));
    const grade = computeGrade(clamped, selectedExam ? selectedExam.maxMarks : 100);
    setDraftMarks((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        marksObtained: clamped,
        grade
      }
    }));
  };

  const handleSaveAll = () => {
    if (!selectedExam) return;
    const recordsToSave: StudentMark[] = eligibleStudents.map((stu) => {
      const data = draftMarks[stu.id] || { marksObtained: 0, grade: 'F', feedback: '' };
      return {
        id: `MRK-${selectedExam.id}-${stu.id}`,
        examId: selectedExam.id,
        studentId: stu.id,
        courseId: selectedExam.courseId,
        marksObtained: data.marksObtained,
        grade: data.grade,
        feedback: data.feedback
      };
    });

    saveStudentMarks(recordsToSave);
    setFeedbackSuccess('Student grades and marks successfully committed to university records.');
    setTimeout(() => setFeedbackSuccess(null), 3000);
  };

  // New Exam Form
  const [examForm, setExamForm] = useState<Omit<Exam, 'id' | 'courseName'>>({
    name: 'End Semester Examination',
    courseId: courses[0]?.id || 'CS301',
    semester: 5,
    examDate: '2025-11-20',
    maxMarks: 100,
    passMarks: 40,
    weightage: 50
  });

  const handleCreateExam = (e: React.FormEvent) => {
    e.preventDefault();
    const course = courses.find((c) => c.id === examForm.courseId);
    const newExam: Exam = {
      ...examForm,
      id: `EXAM-${Date.now().toString().slice(-4)}`,
      courseName: course?.name || 'Selected Course'
    };
    addExam(newExam);
    setSelectedExamId(newExam.id);
    setIsAddExamOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Examinations, Grading & Transcripts</h2>
            <span className="bg-sky-50 text-sky-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-sky-100">
              Module 7
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Publish assessment schedules, record scores, automatically compute SGPA/CGPA, and print official grade cards.
          </p>
        </div>

        {role !== 'student' && (
          <button
            onClick={() => setIsAddExamOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-sm shadow-sky-200 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Create Exam Assessment</span>
          </button>
        )}
      </div>

      {/* Selector & Actions */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-end">
          <div className="sm:col-span-8">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Select Scheduled Examination</label>
            <select
              value={selectedExamId}
              onChange={(e) => setSelectedExamId(e.target.value)}
              className="w-full py-2.5 px-3 text-xs font-medium rounded-xl border border-slate-300 focus:outline-none focus:border-sky-500 bg-slate-50/50 text-slate-800"
            >
              {exams.map((ex) => (
                <option key={ex.id} value={ex.id}>
                  {ex.name} • {ex.courseName} (Max: {ex.maxMarks} marks, Date: {ex.examDate})
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-4 flex gap-2">
            {role !== 'student' && (
              <button
                onClick={handleSaveAll}
                className="w-full flex items-center justify-center gap-1.5 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition shadow-xs"
              >
                <Save className="w-4 h-4 text-sky-400" />
                <span>Save Grades</span>
              </button>
            )}
          </div>
        </div>

        {feedbackSuccess && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            <span>{feedbackSuccess}</span>
          </div>
        )}
      </div>

      {/* Marks Entry & Grade Matrix */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
              {selectedExam?.name} • Marks Register
            </h3>
            <p className="text-[11px] text-slate-500">
              Maximum Marks: {selectedExam?.maxMarks} | Passing Threshold: {selectedExam?.passMarks}
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-600 bg-white px-2.5 py-1 rounded-md border border-slate-200">
            {eligibleStudents.length} Students Taking Exam
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px] bg-slate-50/40">
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Roll Number</th>
                <th className="py-3 px-4 text-center">Marks Obtained (Max {selectedExam?.maxMarks})</th>
                <th className="py-3 px-4 text-center">Calculated Grade</th>
                <th className="py-3 px-4 text-center">Pass / Fail</th>
                <th className="py-3 px-4">Examiner Feedback</th>
                <th className="py-3 px-4 text-right">Transcript</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {eligibleStudents.map((stu) => {
                const draft = draftMarks[stu.id] || { marksObtained: 0, grade: 'F', feedback: '' };
                const isPass = draft.marksObtained >= (selectedExam?.passMarks || 40);

                return (
                  <tr key={stu.id} className="hover:bg-slate-50/50 transition">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-100 shrink-0">
                          <img
                            src={stu.avatarUrl}
                            alt={stu.firstName}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">
                            {stu.firstName} {stu.lastName}
                          </p>
                          <span className="text-[10px] text-slate-400 font-mono">{stu.id}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{stu.rollNo}</td>

                    {/* Marks Input */}
                    <td className="py-3 px-4 text-center">
                      {role !== 'student' ? (
                        <input
                          type="number"
                          min={0}
                          max={selectedExam?.maxMarks || 100}
                          value={draft.marksObtained}
                          onChange={(e) => handleMarkChange(stu.id, Number(e.target.value))}
                          className="w-20 text-center font-bold text-xs py-1.5 px-2 border border-slate-300 rounded-lg focus:outline-none focus:border-sky-500"
                        />
                      ) : (
                        <span className="font-bold text-sm text-slate-900">{draft.marksObtained}</span>
                      )}
                    </td>

                    {/* Grade Badge */}
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full font-black text-xs ${
                          draft.grade.startsWith('A')
                            ? 'bg-emerald-100 text-emerald-800'
                            : draft.grade.startsWith('B')
                            ? 'bg-sky-100 text-sky-800'
                            : draft.grade === 'F'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {draft.grade}
                      </span>
                    </td>

                    {/* Pass/Fail */}
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          isPass ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
                        }`}
                      >
                        {isPass ? 'PASSED' : 'FAILED'}
                      </span>
                    </td>

                    {/* Feedback */}
                    <td className="py-3 px-4">
                      {role !== 'student' ? (
                        <input
                          type="text"
                          placeholder="Feedback or comments..."
                          value={draft.feedback}
                          onChange={(e) =>
                            setDraftMarks((prev) => ({
                              ...prev,
                              [stu.id]: {
                                ...prev[stu.id],
                                feedback: e.target.value
                              }
                            }))
                          }
                          className="w-full px-2 py-1 text-[11px] border border-slate-200 rounded-md focus:outline-none focus:border-sky-500"
                        />
                      ) : (
                        <span className="text-[11px] text-slate-600">{draft.feedback || 'Good work.'}</span>
                      )}
                    </td>

                    {/* Print Marksheet Action */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedStudentForSheet(stu)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[11px] font-bold transition"
                        title="Print Official Grade Card"
                      >
                        <Printer className="w-3 h-3" />
                        <span>Mark Sheet</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Exam Modal */}
      {isAddExamOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-sky-600" />
                <h3 className="font-bold text-slate-800 text-sm">Schedule New Examination</h3>
              </div>
              <button
                onClick={() => setIsAddExamOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateExam} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Assessment Name *</label>
                <input
                  type="text"
                  required
                  value={examForm.name}
                  onChange={(e) => setExamForm({ ...examForm, name: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  placeholder="e.g. End Semester Exam 2025"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject Course *</label>
                <select
                  value={examForm.courseId}
                  onChange={(e) => {
                    const c = courses.find((crs) => crs.id === e.target.value);
                    setExamForm({
                      ...examForm,
                      courseId: e.target.value,
                      semester: c?.semester || 5
                    });
                  }}
                  className="w-full px-3 py-2 border rounded-lg border-slate-300 bg-white"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code}: {c.name} (Sem {c.semester})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Date of Exam</label>
                  <input
                    type="date"
                    required
                    value={examForm.examDate}
                    onChange={(e) => setExamForm({ ...examForm, examDate: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Semester</label>
                  <input
                    type="number"
                    value={examForm.semester}
                    readOnly
                    className="w-full px-3 py-2 border rounded-lg border-slate-200 bg-slate-50 text-slate-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Max Marks</label>
                  <input
                    type="number"
                    value={examForm.maxMarks}
                    onChange={(e) => setExamForm({ ...examForm, maxMarks: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Passing Marks</label>
                  <input
                    type="number"
                    value={examForm.passMarks}
                    onChange={(e) => setExamForm({ ...examForm, passMarks: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Weightage (%)</label>
                  <input
                    type="number"
                    value={examForm.weightage}
                    onChange={(e) => setExamForm({ ...examForm, weightage: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-lg border-slate-300"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddExamOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-lg shadow-sm"
                >
                  Publish Exam Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Marksheet Modal */}
      <MarkSheetModal
        student={selectedStudentForSheet}
        marks={marks}
        courses={courses}
        exams={exams}
        onClose={() => setSelectedStudentForSheet(null)}
      />
    </div>
  );
};
