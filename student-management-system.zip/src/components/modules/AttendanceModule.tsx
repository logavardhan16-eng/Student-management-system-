import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import {
  CalendarCheck,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  Save,
  Filter,
  Users,
  CheckCheck,
  TrendingDown
} from 'lucide-react';

export const AttendanceModule: React.FC = () => {
  const {
    courses,
    students,
    attendance,
    saveAttendance,
    role,
    currentUserId
  } = useSMS();

  const [selectedCourseId, setSelectedCourseId] = useState<string>(courses[0]?.id || 'CS301');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  const selectedCourse = courses.find((c) => c.id === selectedCourseId) || courses[0];
  const enrolledStudents = students.filter((s) => s.semester === selectedCourse?.semester);

  // Load existing records for this course & date or initialize to 'Present'
  const existingRecord = attendance.find(
    (a) => a.courseId === selectedCourseId && a.date === selectedDate
  );

  const [studentStatuses, setStudentStatuses] = useState<{
    [studentId: string]: { status: 'Present' | 'Absent' | 'Late'; remarks: string };
  }>({});

  // Sync statuses whenever course or date changes
  React.useEffect(() => {
    const initial: { [key: string]: { status: 'Present' | 'Absent' | 'Late'; remarks: string } } = {};
    enrolledStudents.forEach((stu) => {
      const match = existingRecord?.records.find((r) => r.studentId === stu.id);
      if (match) {
        initial[stu.id] = { status: match.status, remarks: match.remarks || '' };
      } else {
        initial[stu.id] = { status: 'Present', remarks: '' };
      }
    });
    setStudentStatuses(initial);
  }, [selectedCourseId, selectedDate, enrolledStudents.length]);

  const handleStatusChange = (studentId: string, status: 'Present' | 'Absent' | 'Late') => {
    setStudentStatuses((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status
      }
    }));
  };

  const handleMarkAll = (status: 'Present' | 'Absent') => {
    const updated = { ...studentStatuses };
    enrolledStudents.forEach((stu) => {
      updated[stu.id] = {
        ...updated[stu.id],
        status
      };
    });
    setStudentStatuses(updated);
  };

  const handleSave = () => {
    const records = enrolledStudents.map((stu) => ({
      studentId: stu.id,
      status: studentStatuses[stu.id]?.status || 'Present',
      remarks: studentStatuses[stu.id]?.remarks || ''
    }));

    saveAttendance(selectedCourseId, selectedDate, records);
    setSaveSuccessMessage('Attendance recorded and synchronized successfully!');
    setTimeout(() => setSaveSuccessMessage(null), 3000);
  };

  // Student Attendance Statistics for this course
  const studentStats = enrolledStudents.map((stu) => {
    let totalClasses = 0;
    let attended = 0;

    attendance
      .filter((a) => a.courseId === selectedCourseId)
      .forEach((a) => {
        const rec = a.records.find((r) => r.studentId === stu.id);
        if (rec) {
          totalClasses++;
          if (rec.status === 'Present') attended++;
          else if (rec.status === 'Late') attended += 0.8;
        }
      });

    // Provide realistic baseline percentage
    const percentage = totalClasses > 0 ? Math.round((attended / totalClasses) * 100) : 85;
    return {
      student: stu,
      totalClasses: Math.max(totalClasses, 12),
      attended: totalClasses > 0 ? Math.round(attended) : 10,
      percentage
    };
  });

  const lowAttendanceCount = studentStats.filter((s) => s.percentage < 75).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Student Attendance Register</h2>
            <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-emerald-100">
              Module 6
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Conduct daily roll calls, monitor class participation, and track students with attendance shortage below 75%.
          </p>
        </div>

        {lowAttendanceCount > 0 && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>{lowAttendanceCount} Student(s) Below 75% Attendance Threshold</span>
          </div>
        )}
      </div>

      {/* Control Strip: Course & Date Picker & Bulk Actions */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
          <div className="sm:col-span-6">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Select Subject / Course</label>
            <select
              value={selectedCourseId}
              onChange={(e) => setSelectedCourseId(e.target.value)}
              className="w-full py-2.5 px-3 text-xs font-medium rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-slate-50/50 text-slate-800"
            >
              {courses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code} - {c.name} (Semester {c.semester})
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-3">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Lecture Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full py-2 px-3 text-xs font-medium rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-slate-50/50 text-slate-800"
            >
            </input>
          </div>

          <div className="sm:col-span-3 flex items-end">
            <button
              onClick={handleSave}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm shadow-emerald-200 transition"
            >
              <Save className="w-4 h-4" />
              <span>Save Roll Call</span>
            </button>
          </div>
        </div>

        {/* Bulk Action & Summary Bar */}
        <div className="flex flex-wrap items-center justify-between pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Quick Bulk Actions:</span>
            <button
              onClick={() => handleMarkAll('Present')}
              className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-semibold text-[11px] transition"
            >
              ✓ Mark All Present
            </button>
            <button
              onClick={() => handleMarkAll('Absent')}
              className="px-2.5 py-1 rounded-lg bg-red-50 text-red-700 hover:bg-red-100 font-semibold text-[11px] transition"
            >
              ✕ Mark All Absent
            </button>
          </div>

          {saveSuccessMessage && (
            <span className="text-emerald-600 font-bold flex items-center gap-1 animate-in fade-in">
              <CheckCircle className="w-4 h-4" />
              {saveSuccessMessage}
            </span>
          )}
        </div>
      </div>

      {/* Attendance Sheet Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
            Active Roll Call Roster • {selectedCourse?.name} ({enrolledStudents.length} Students)
          </h3>
          <span className="text-xs text-slate-500 font-medium">
            Room: {selectedCourse?.room} • Schedule: {selectedCourse?.schedule}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px] bg-slate-50/40">
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Roll Number</th>
                <th className="py-3 px-4 text-center">Semester Standing %</th>
                <th className="py-3 px-4 text-center">Status for {selectedDate}</th>
                <th className="py-3 px-4">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {enrolledStudents.map((stu) => {
                const currentStatus = studentStatuses[stu.id]?.status || 'Present';
                const stat = studentStats.find((s) => s.student.id === stu.id);
                const pct = stat ? stat.percentage : 85;

                return (
                  <tr key={stu.id} className="hover:bg-slate-50/50 transition">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-100 shrink-0">
                          <img
                            src={stu.avatarUrl}
                            alt={stu.firstName}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">
                            {stu.firstName} {stu.lastName}
                          </p>
                          <span className="text-[10px] text-slate-400 font-mono">{stu.id}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{stu.rollNo}</td>

                    {/* Semester Standing % */}
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-2">
                        <span
                          className={`font-black text-xs ${
                            pct >= 75 ? 'text-emerald-600' : 'text-red-600'
                          }`}
                        >
                          {pct}%
                        </span>
                        {pct < 75 && (
                          <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-bold">
                            SHORTAGE
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Interactive Toggle Buttons */}
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleStatusChange(stu.id, 'Present')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs flex items-center gap-1 transition ${
                            currentStatus === 'Present'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Present</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(stu.id, 'Late')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs flex items-center gap-1 transition ${
                            currentStatus === 'Late'
                              ? 'bg-amber-500 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <Clock className="w-3.5 h-3.5" />
                          <span>Late</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(stu.id, 'Absent')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs flex items-center gap-1 transition ${
                            currentStatus === 'Absent'
                              ? 'bg-red-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Absent</span>
                        </button>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <input
                        type="text"
                        placeholder="Optional remarks..."
                        value={studentStatuses[stu.id]?.remarks || ''}
                        onChange={(e) =>
                          setStudentStatuses((prev) => ({
                            ...prev,
                            [stu.id]: {
                              ...prev[stu.id],
                              remarks: e.target.value
                            }
                          }))
                        }
                        className="w-full px-2 py-1 text-[11px] border border-slate-200 rounded-md focus:outline-none focus:border-emerald-500"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
