import React, { useState } from 'react';
import { useSMS } from '../../context/SMSContext';
import { UserRole } from '../../types';
import {
  GraduationCap,
  Bell,
  UserCheck,
  Shield,
  BookOpen,
  ChevronDown,
  Check,
  X,
  Building,
  Sparkles
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    role,
    setRole,
    currentUserId,
    setCurrentUserId,
    students,
    teachers,
    notifications,
    setActiveTab
  } = useSMS();

  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const currentStudent = students.find((s) => s.id === currentUserId);
  const currentTeacher = teachers.find((t) => t.id === currentUserId);

  const unreadCount = notifications.length;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand & Institution Info */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-700 flex items-center justify-center text-white shadow-sm shadow-indigo-200">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-slate-900 tracking-tight leading-none">
                Apex SMS
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                Academic ERP
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">Student Management System</p>
          </div>
        </div>

        {/* Center/Right Control Cluster */}
        <div className="flex items-center gap-3">
          {/* Active Role Selector */}
          <div className="relative">
            <button
              onClick={() => {
                setShowRoleMenu(!showRoleMenu);
                setShowUserMenu(false);
                setShowNotifMenu(false);
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-slate-300 bg-slate-50/80 hover:bg-slate-100 text-xs font-semibold text-slate-800 transition"
              title="Switch role mode to test permissions"
            >
              {role === 'admin' && <Shield className="w-3.5 h-3.5 text-purple-600" />}
              {role === 'teacher' && <BookOpen className="w-3.5 h-3.5 text-blue-600" />}
              {role === 'student' && <UserCheck className="w-3.5 h-3.5 text-emerald-600" />}
              <span className="capitalize">Role: {role}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showRoleMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-50 text-xs animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1.5 font-semibold text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-100">
                  Select Perspective
                </div>
                <button
                  onClick={() => {
                    setRole('admin');
                    setShowRoleMenu(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium"
                >
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-purple-600" />
                    <span>Admin Portal</span>
                  </div>
                  {role === 'admin' && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                </button>
                <button
                  onClick={() => {
                    setRole('teacher');
                    setShowRoleMenu(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium"
                >
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-blue-600" />
                    <span>Teacher / Faculty</span>
                  </div>
                  {role === 'teacher' && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                </button>
                <button
                  onClick={() => {
                    setRole('student');
                    setShowRoleMenu(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium"
                >
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-emerald-600" />
                    <span>Student Portal</span>
                  </div>
                  {role === 'student' && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                </button>
              </div>
            )}
          </div>

          {/* User Persona Switcher (When testing as specific teacher or student) */}
          {role !== 'admin' && (
            <div className="relative">
              <button
                onClick={() => {
                  setShowUserMenu(!showUserMenu);
                  setShowRoleMenu(false);
                  setShowNotifMenu(false);
                }}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-50 text-xs font-medium text-indigo-900 transition"
              >
                <span className="truncate max-w-[120px] sm:max-w-[160px]">
                  {role === 'student'
                    ? currentStudent
                      ? `${currentStudent.firstName} (${currentStudent.rollNo})`
                      : 'Select Student'
                    : currentTeacher
                    ? currentTeacher.name
                    : 'Select Teacher'}
                </span>
                <ChevronDown className="w-3 h-3 text-indigo-500" />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 text-xs max-h-72 overflow-y-auto">
                  <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    {role === 'student' ? 'Switch Student Account' : 'Switch Faculty Account'}
                  </div>
                  {role === 'student'
                    ? students.map((stu) => (
                        <button
                          key={stu.id}
                          onClick={() => {
                            setCurrentUserId(stu.id);
                            setShowUserMenu(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 ${
                            currentUserId === stu.id ? 'bg-indigo-50/60 font-semibold text-indigo-700' : 'text-slate-700'
                          }`}
                        >
                          <div>
                            <p className="font-medium">{stu.firstName} {stu.lastName}</p>
                            <p className="text-[10px] text-slate-400">{stu.rollNo} • Sem {stu.semester}</p>
                          </div>
                          {currentUserId === stu.id && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                        </button>
                      ))
                    : teachers.map((tch) => (
                        <button
                          key={tch.id}
                          onClick={() => {
                            setCurrentUserId(tch.id);
                            setShowUserMenu(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 ${
                            currentUserId === tch.id ? 'bg-indigo-50/60 font-semibold text-indigo-700' : 'text-slate-700'
                          }`}
                        >
                          <div>
                            <p className="font-medium">{tch.name}</p>
                            <p className="text-[10px] text-slate-400">{tch.department}</p>
                          </div>
                          {currentUserId === tch.id && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                        </button>
                      ))}
                </div>
              )}
            </div>
          )}

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifMenu(!showNotifMenu);
                setShowRoleMenu(false);
                setShowUserMenu(false);
              }}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 relative transition"
              title="Campus Notices"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 ring-2 ring-white" />
              )}
            </button>

            {showNotifMenu && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 p-4 z-50 text-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <h4 className="font-bold text-slate-800 text-sm">Notice Board</h4>
                  </div>
                  <span className="text-[11px] bg-slate-100 px-2 py-0.5 rounded-full font-medium text-slate-600">
                    {notifications.length} Active
                  </span>
                </div>

                <div className="mt-3 space-y-2.5 max-h-64 overflow-y-auto pr-1">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 hover:border-slate-200 transition"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          n.category === 'Exam'
                            ? 'bg-purple-100 text-purple-700'
                            : n.category === 'Fee'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-indigo-100 text-indigo-700'
                        }`}>
                          {n.category}
                        </span>
                        <span className="text-[10px] text-slate-400">{n.date}</span>
                      </div>
                      <h5 className="font-semibold text-slate-800 mt-1">{n.title}</h5>
                      <p className="text-[11px] text-slate-600 line-clamp-2 mt-0.5">{n.content}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 text-center">
                  <button
                    onClick={() => {
                      setActiveTab('notifications');
                      setShowNotifMenu(false);
                    }}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    View All Announcements →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
