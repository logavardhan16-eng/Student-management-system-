import React from 'react';
import { useSMS } from '../../context/SMSContext';
import { ActiveTab } from '../../types';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  CalendarCheck,
  Award,
  CreditCard,
  Clock,
  BarChart3,
  Bell,
  Database,
  ChevronRight
} from 'lucide-react';

interface NavItem {
  tab: ActiveTab;
  label: string;
  moduleNo: number;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | number;
}

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, role, students, fees, attendance } = useSMS();

  // Count pending fees
  const pendingFeesCount = fees.filter((f) => f.status === 'Pending' || f.status === 'Overdue').length;

  const navItems: NavItem[] = [
    { tab: 'dashboard', label: 'Dashboard', moduleNo: 3, icon: LayoutDashboard },
    { tab: 'students', label: 'Student Directory', moduleNo: 1, icon: Users, badge: students.length },
    { tab: 'teachers', label: 'Faculty & Staff', moduleNo: 4, icon: GraduationCap },
    { tab: 'courses', label: 'Course Management', moduleNo: 5, icon: BookOpen },
    { tab: 'attendance', label: 'Attendance Records', moduleNo: 6, icon: CalendarCheck },
    { tab: 'exams', label: 'Exams & Mark Sheets', moduleNo: 7, icon: Award },
    { tab: 'fees', label: 'Fee Management', moduleNo: 8, icon: CreditCard, badge: pendingFeesCount > 0 ? `${pendingFeesCount} Due` : undefined },
    { tab: 'timetable', label: 'Class Timetable', moduleNo: 9, icon: Clock },
    { tab: 'reports', label: 'Reports & Analytics', moduleNo: 10, icon: BarChart3 },
    { tab: 'notifications', label: 'Notice Board', moduleNo: 11, icon: Bell },
    { tab: 'database', label: 'Database & Project Docs', moduleNo: 12, icon: Database }
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 min-h-[calc(100vh-4rem)] border-r border-slate-800">
      {/* Role Context Chip */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="bg-slate-800/80 rounded-xl p-3 border border-slate-700/60">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Current View</span>
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>
          <p className="font-semibold text-white text-sm capitalize mt-0.5">
            {role === 'admin' ? 'Administrative Suite' : role === 'teacher' ? 'Faculty Portal' : 'Student Portal'}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">All 12 Modules Accessible</p>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
          SMS System Modules
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.tab;

          return (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/30'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`} />
                <span className="truncate">{item.label}</span>
              </div>

              <div className="flex items-center gap-1.5">
                {item.badge !== undefined && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive
                        ? 'bg-indigo-700/90 text-white'
                        : typeof item.badge === 'string' && item.badge.includes('Due')
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-indigo-300" />}
              </div>
            </button>
          );
        })}
      </nav>

      {/* System Footer info */}
      <div className="p-4 border-t border-slate-800/80 text-[11px] text-slate-400 bg-slate-950/40">
        <div className="flex items-center justify-between mb-1">
          <span className="font-semibold text-slate-300">System v2.5</span>
          <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">Client DB</span>
        </div>
        <p className="text-[10px] text-slate-500 leading-tight">
          Apex Autonomous College Management System
        </p>
      </div>
    </aside>
  );
};
