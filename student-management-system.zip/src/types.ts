export type UserRole = 'admin' | 'teacher' | 'student';

export interface Student {
  id: string; // e.g. "STU-2025-001"
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Other';
  department: string; // e.g. "Computer Science & Engineering"
  degree: string; // e.g. "B.Tech"
  semester: number; // 1 to 8
  batch: string; // e.g. "2023-2027"
  rollNo: string; // e.g. "CS23B042"
  address: string;
  bloodGroup: string;
  guardianName: string;
  guardianPhone: string;
  enrollmentDate: string;
  status: 'Active' | 'Inactive' | 'Graduated';
  avatarUrl?: string;
}

export interface Teacher {
  id: string; // e.g. "FAC-101"
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string; // e.g. "Associate Professor", "Assistant Professor"
  qualification: string; // e.g. "Ph.D. in Computer Science"
  joiningDate: string;
  assignedCourses: string[]; // array of course IDs
  officeRoom: string;
  status: 'Active' | 'On Leave';
  avatarUrl?: string;
}

export interface Course {
  id: string; // e.g. "CS301"
  name: string;
  code: string; // e.g. "CS301"
  department: string;
  semester: number;
  credits: number;
  instructorId: string; // Teacher ID
  instructorName?: string;
  capacity: number;
  enrolledCount: number;
  description: string;
  schedule: string; // e.g. "Mon, Wed, Fri 10:00 AM"
  room: string;
}

export interface AttendanceRecord {
  id: string;
  courseId: string;
  date: string; // YYYY-MM-DD
  records: {
    studentId: string;
    status: 'Present' | 'Absent' | 'Late';
    remarks?: string;
  }[];
}

export interface Exam {
  id: string;
  name: string; // e.g. "Midterm Examination - Fall 2025"
  courseId: string;
  courseName: string;
  semester: number;
  examDate: string;
  maxMarks: number;
  passMarks: number;
  weightage: number; // e.g. 30%
}

export interface StudentMark {
  id: string;
  examId: string;
  studentId: string;
  courseId: string;
  marksObtained: number;
  grade: 'A+' | 'A' | 'B+' | 'B' | 'C' | 'D' | 'F';
  feedback?: string;
}

export interface FeeRecord {
  id: string; // Receipt / Invoice ID e.g. "FEE-2025-0891"
  studentId: string;
  academicYear: string;
  semester: number;
  totalAmount: number;
  paidAmount: number;
  dueDate: string;
  status: 'Paid' | 'Pending' | 'Partial' | 'Overdue';
  breakdown: {
    tuition: number;
    lab: number;
    library: number;
    examination: number;
    other: number;
  };
  transactions: {
    txId: string;
    date: string;
    amount: number;
    method: 'UPI' | 'Online Banking' | 'Cash' | 'Card' | 'Cheque';
  }[];
}

export interface TimetableSlot {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  timeSlot: string; // e.g. "09:00 - 10:00 AM"
  courseId: string;
  courseName: string;
  teacherId: string;
  teacherName: string;
  room: string;
  semester: number;
  department: string;
}

export interface Notification {
  id: string;
  title: string;
  content: string;
  category: 'Exam' | 'Academic' | 'Holiday' | 'Fee' | 'General';
  targetAudience: 'All' | 'Students' | 'Teachers';
  date: string;
  isImportant: boolean;
  author: string;
}

export type ActiveTab =
  | 'dashboard'
  | 'students'
  | 'teachers'
  | 'courses'
  | 'attendance'
  | 'exams'
  | 'fees'
  | 'timetable'
  | 'reports'
  | 'notifications'
  | 'database';
